/**
 * Clarity Platform Server
 * 
 * Main server file for the Clarity platform.
 */

const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const config = require('./config/config');

// Import routes
const patientsRouter = require('./routes/patients');
const therapistsRouter = require('./routes/therapists');
const insightsRouter = require('./routes/insights');
const literatureRouter = require('./routes/literature');
const rehearsalRouter = require('./routes/rehearsal');
const screeningRouter = require('./routes/screening');
const treatmentRouter = require('./routes/treatment');
const authRouter = require('./routes/auth');

// Initialize ML models
const { initializePaperEmbeddings } = require('./ml/paperSimilarity');

// Create Express app
const app = express();
const PORT = config.server.port;

// Middleware
app.use(cors({
  origin: config.server.corsOrigins,
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Logging middleware
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
  next();
});

// Routes
app.use('/api/patients', patientsRouter);
app.use('/api/therapists', therapistsRouter);
app.use('/api/insights', insightsRouter);
app.use('/api/literature', literatureRouter);
app.use('/api/rehearsal', rehearsalRouter);
app.use('/api/screening', screeningRouter);
app.use('/api/treatment', treatmentRouter);
app.use('/api/auth', authRouter);

// Serve static files in production
if (config.server.environment === 'production') {
  app.use(express.static(path.join(__dirname, '../client/build')));
  
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../client/build', 'index.html'));
  });
}

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  
  const statusCode = err.statusCode || 500;
  const message = err.message || 'Internal Server Error';
  const code = err.code || 'INTERNAL_ERROR';
  
  res.status(statusCode).json({
    error: {
      code,
      message,
      status: statusCode
    }
  });
});

// Initialize server
async function startServer() {
  try {
    // Create necessary directories if they don't exist
    const dirs = [
      config.paths.patients,
      config.paths.literature,
      config.paths.models,
      config.paths.logs
    ];
    
    for (const dir of dirs) {
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
        console.log(`Created directory: ${dir}`);
      }
    }
    
    // Initialize ML models
    console.log('Initializing ML models...');
    await initializePaperEmbeddings();
    
    // Start server
    app.listen(PORT, () => {
      console.log(`Clarity server running on port ${PORT}`);
      console.log(`Environment: ${config.server.environment}`);
      console.log(`Using ${config.useSimulatedResponses ? 'simulated' : 'real'} OpenAI responses`);
    });
  } catch (error) {
    console.error('Error starting server:', error);
    process.exit(1);
  }
}

// Start the server
startServer();