/**
 * Treatment Recommendation ML Model
 */

const config = require('../config/config');
const { createChatCompletion } = require('../utils/openai');

/**
 * Generate treatment recommendations
 * @param {Object} patientData - Patient information
 * @param {Array} screeningResults - Screening results
 * @returns {Promise<Object>} Treatment recommendations
 */
async function generateTreatmentRecommendations(patientData, screeningResults) {
  // Format patient data
  const patientInfo = `
Patient: ${patientData.name}, ${patientData.age}, ${patientData.gender}
Diagnosis: ${patientData.diagnosis ? patientData.diagnosis.join(', ') : 'None'}
  `.trim();
  
  // Format screening results
  const formattedScreening = screeningResults.map(result => 
    `${result.condition} (${result.probability}): ${result.description}`
  ).join('\n');
  
  // Create prompt for the model
  const response = await createChatCompletion({
    model: config.openai.models.chat,
    messages: [
      {
        role: "system",
        content: "You are a clinical psychologist. Create a treatment plan in markdown format."
      },
      {
        role: "user",
        content: `${patientInfo}\n\n${formattedScreening}\n\nGenerate treatment plan.`
      }
    ],
    temperature: 0.4,
    max_tokens: config.openai.maxTokens.treatmentRecommendations
  }, 'treatment_recommendations');
  
  // Return the recommendations
  return {
    recommendations: response.choices[0].message.content,
    timestamp: new Date().toISOString()
  };
}

module.exports = {
  generateTreatmentRecommendations
};