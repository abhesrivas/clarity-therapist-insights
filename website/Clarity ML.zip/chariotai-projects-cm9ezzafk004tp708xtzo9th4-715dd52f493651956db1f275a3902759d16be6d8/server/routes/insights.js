/**
 * Insights API Routes
 * 
 * This file contains all routes for AI insights.
 */

const express = require('express');
const router = express.Router();
const { authenticateToken } = require('../middleware/auth');
const insightsController = require('../controllers/insights');

// Apply authentication middleware to all routes
router.use(authenticateToken);

/**
 * @route GET /api/insights/patients/:patientId
 * @desc Get patient insights
 * @access Private
 */
router.get('/patients/:patientId', insightsController.getPatientInsights);

/**
 * @route POST /api/insights/patients/:patientId/generate
 * @desc Generate new insights
 * @access Private
 */
router.post('/patients/:patientId/generate', insightsController.generateNewInsights);

/**
 * @route GET /api/insights/patients/:patientId/language-analysis
 * @desc Get language analysis
 * @access Private
 */
router.get('/patients/:patientId/language-analysis', insightsController.getLanguageAnalysis);

/**
 * @route POST /api/insights/patients/:patientId/language-analysis
 * @desc Generate language analysis
 * @access Private
 */
router.post('/patients/:patientId/language-analysis', insightsController.generateLanguageAnalysis);

/**
 * @route GET /api/insights/patients/:patientId/sentiment-trend
 * @desc Get sentiment trend
 * @access Private
 */
router.get('/patients/:patientId/sentiment-trend', insightsController.getSentimentTrend);

/**
 * @route GET /api/insights/patients/:patientId/topic-analysis
 * @desc Get topic analysis
 * @access Private
 */
router.get('/patients/:patientId/topic-analysis', insightsController.getTopicAnalysis);

module.exports = router;