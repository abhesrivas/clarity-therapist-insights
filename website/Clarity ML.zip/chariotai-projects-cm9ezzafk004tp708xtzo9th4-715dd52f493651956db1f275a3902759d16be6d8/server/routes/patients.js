/**
 * Patients API Routes
 * 
 * This file contains all routes for patient data.
 */

const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const config = require('../config/config');

// Import middleware
const { authenticateToken } = require('../middleware/auth');

// Import controllers
const patientsController = require('../controllers/patients');

// Apply authentication middleware to all routes
router.use(authenticateToken);

/**
 * @route GET /api/patients
 * @desc Get all patients
 * @access Private
 */
router.get('/', patientsController.getAllPatients);

/**
 * @route GET /api/patients/:patientId
 * @desc Get patient details
 * @access Private
 */
router.get('/:patientId', patientsController.getPatientDetails);

/**
 * @route POST /api/patients
 * @desc Create a new patient
 * @access Private
 */
router.post('/', patientsController.createPatient);

/**
 * @route PUT /api/patients/:patientId
 * @desc Update patient details
 * @access Private
 */
router.put('/:patientId', patientsController.updatePatient);

/**
 * @route DELETE /api/patients/:patientId
 * @desc Delete a patient
 * @access Private
 */
router.delete('/:patientId', patientsController.deletePatient);

/**
 * @route GET /api/patients/:patientId/history
 * @desc Get patient history
 * @access Private
 */
router.get('/:patientId/history', patientsController.getPatientHistory);

/**
 * @route POST /api/patients/:patientId/history
 * @desc Add history entry
 * @access Private
 */
router.post('/:patientId/history', patientsController.addHistoryEntry);

/**
 * @route GET /api/patients/:patientId/history/:historyId
 * @desc Get specific history entry
 * @access Private
 */
router.get('/:patientId/history/:historyId', patientsController.getHistoryEntry);

/**
 * @route PUT /api/patients/:patientId/history/:historyId
 * @desc Update history entry
 * @access Private
 */
router.put('/:patientId/history/:historyId', patientsController.updateHistoryEntry);

/**
 * @route DELETE /api/patients/:patientId/history/:historyId
 * @desc Delete history entry
 * @access Private
 */
router.delete('/:patientId/history/:historyId', patientsController.deleteHistoryEntry);

/**
 * @route POST /api/patients/:patientId/history/:historyId/insights
 * @desc Generate insights for a session
 * @access Private
 */
router.post('/:patientId/history/:historyId/insights', patientsController.generateSessionInsights);

module.exports = router;