/**
 * Literature API Routes
 * 
 * This file contains all routes for literature review.
 */

const express = require('express');
const router = express.Router();
const { authenticateToken } = require('../middleware/auth');
const literatureController = require('../controllers/literature');

// Apply authentication middleware to all routes
router.use(authenticateToken);

/**
 * @route GET /api/literature/search
 * @desc Search literature
 * @access Private
 */
router.get('/search', literatureController.searchLiterature);

/**
 * @route GET /api/literature/summary
 * @desc Get literature summary
 * @access Private
 */
router.get('/summary', literatureController.getLiteratureSummary);

/**
 * @route GET /api/literature/papers/:paperId
 * @desc Get paper details
 * @access Private
 */
router.get('/papers/:paperId', literatureController.getPaperDetails);

/**
 * @route GET /api/literature/papers
 * @desc Get all papers
 * @access Private
 */
router.get('/papers', literatureController.getAllPapers);

/**
 * @route POST /api/literature/papers
 * @desc Add a new paper
 * @access Private
 */
router.post('/papers', literatureController.addPaper);

/**
 * @route POST /api/literature/generate-embeddings
 * @desc Generate embeddings for papers
 * @access Private
 */
router.post('/generate-embeddings', literatureController.generateEmbeddings);

module.exports = router;