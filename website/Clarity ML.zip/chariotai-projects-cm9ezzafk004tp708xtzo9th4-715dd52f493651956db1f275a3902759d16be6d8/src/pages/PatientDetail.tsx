import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  ArrowLeftIcon,
  ClipboardDocumentListIcon,
  ChartBarIcon,
  ChatBubbleLeftRightIcon,
  CalendarIcon,
  PencilIcon,
  ExclamationTriangleIcon
} from '@heroicons/react/24/outline';
import { useNotification } from '../context/NotificationContext';

// Mock data
const mockPatients = {
  'p1': {
    id: 'p1',
    name: 'Sarah Johnson',
    age: 34,
    gender: 'Female',
    diagnosis: ['Generalized Anxiety Disorder', 'Insomnia'],
    lastSession: '2023-06-15',
    nextSession: '2023-06-22',
    riskLevel: 'Low',
    status: 'Active',
    therapistId: 't1',
    contactInfo: {
      email: 'sarah.j@example.com',
      phone: '(555) 123-4567',
      address: '123 Main St, Anytown, CA 94321'
    },
    insurance: {
      provider: 'Blue Cross Blue Shield',
      policyNumber: 'BCBS-12345678',
      groupNumber: 'GRP-987654'
    },
    emergencyContact: {
      name: 'John Johnson',
      relationship: 'Husband',
      phone: '(555) 987-6543'
    },
    metrics: {
      anxiety: 60,
      depression: 38,
      sleep: 45,
      adherence: 85
    }
  },
  'p2': {
    id: 'p2',
    name: 'Michael Chen',
    age: 42,
    gender: 'Male',
    diagnosis: ['Major Depressive Disorder', 'Social Anxiety Disorder'],
    lastSession: '2023-06-10',
    nextSession: '2023-06-24',
    riskLevel: 'Moderate',
    status: 'Active',
    therapistId: 't2',
    contactInfo: {
      email: 'michael.c@example.com',
      phone: '(555) 234-5678',
      address: '456 Oak Ave, Somewhere, CA 94123'
    },
    insurance: {
      provider: 'Aetna',
      policyNumber: 'AET-87654321',
      groupNumber: 'GRP-123456'
    },
    emergencyContact: {
      name: 'Lisa Chen',
      relationship: 'Wife',
      phone: '(555) 876-5432'
    },
    metrics: {
      anxiety: 58,
      depression: 72,
      sleep: 60,
      adherence: 65
    }
  },
  'p3': {
    id: 'p3',
    name: 'Emily Rodriguez',
    age: 28,
    gender: 'Female',
    diagnosis: ['PTSD', 'Panic Disorder'],
    lastSession: '2023-06-12',
    nextSession: '2023-06-23',
    riskLevel: 'Moderate',
    status: 'Active',
    therapistId: 't1',
    contactInfo: {
      email: 'emily.r@example.com',
      phone: '(555) 345-6789',
      address: '789 Pine St, Elsewhere, CA 94567'
    },
    insurance: {
      provider: 'United Healthcare',
      policyNumber: 'UHC-23456789',
      groupNumber: 'GRP-345678'
    },
    emergencyContact: {
      name: 'Maria Rodriguez',
      relationship: 'Mother',
      phone: '(555) 765-4321'
    },
    metrics: {
      anxiety: 75,
      depression: 55,
      sleep: 40,
      adherence: 82
    }
  }
};

const PatientDetail: React.FC = () => {
  const { patientId } = useParams<{ patientId: string }>();
  const navigate = useNavigate();
  const { addNotification } = useNotification();
  const [patient, setPatient] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    // Simulate loading data
    const timer = setTimeout(() => {
      if (patientId && mockPatients[patientId as keyof typeof mockPatients]) {
        setPatient(mockPatients[patientId as keyof typeof mockPatients]);
      } else {
        addNotification({
          type: 'error',
          title: 'Patient Not Found',
          message: 'The requested patient could not be found.',
          autoDismiss: true
        });
        navigate('/patients');
      }
      setIsLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, [patientId, navigate, addNotification]);
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
  };
  
  const getRiskLevelClass = (riskLevel: string) => {
    switch (riskLevel.toLowerCase()) {
      case 'high':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      case 'moderate':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      case 'low':
      default:
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
    }
  };
  
  const getStatusClass = (status: string) => {
    switch (status.toLowerCase()) {
      case 'active':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      case 'inactive':
        return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
    }
  };
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        duration: 0.3
      }
    }
  };
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
      </div>
    );
  }
  
  if (!patient) {
    return (
      <div className="flex flex-col items-center justify-center h-full">
        <ExclamationTriangleIcon className="h-16 w-16 text-yellow-500 mb-4" />
        <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-2">Patient Not Found</h2>
        <p className="text-gray-600 dark:text-gray-400 mb-4">The requested patient could not be found.</p>
        <Link
          to="/patients"
          className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800"
        >
          <ArrowLeftIcon className="h-5 w-5 mr-2" />
          Back to Patients
        </Link>
      </div>
    );
  }
  
  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-6"
    >
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center">
          <Link
            to="/patients"
            className="mr-4 p-2 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
          >
            <ArrowLeftIcon className="h-5 w-5" />
          </Link>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{patient.name}</h1>
        </div>
        
        <div className="flex flex-wrap gap-2">
          <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${getRiskLevelClass(patient.riskLevel)}`}>
            {patient.riskLevel} Risk
          </span>
          <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${getStatusClass(patient.status)}`}>
            {patient.status}
          </span>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
              <h2 className="text-lg font-semibold text-gray-800 dark:text-white">Patient Information</h2>
              <button
                onClick={() => addNotification({
                  type: 'info',
                  title: 'Coming Soon',
                  message: 'The edit feature is coming soon!',
                  autoDismiss: true
                })}
                className="p-2 rounded-full text-gray-500 hover:text-gray-700 hover:bg-gray-100 dark:text-gray-400 dark:hover:text-gray-200 dark:hover:bg-gray-700 transition-colors"
              >
                <PencilIcon className="h-5 w-5" />
              </button>
            </div>
            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <div className="mb-4">
                    <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Age</h3>
                    <p className="mt-1 text-sm text-gray-900 dark:text-white">{patient.age}</p>
                  </div>
                  <div className="mb-4">
                    <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Gender</h3>
                    <p className="mt-1 text-sm text-gray-900 dark:text-white">{patient.gender}</p>
                  </div>
                  <div className="mb-4">
                    <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Diagnosis</h3>
                    <div className="mt-1 space-y-1">
                      {patient.diagnosis.map((diagnosis: string, index: number) => (
                        <p key={index} className="text-sm text-gray-900 dark:text-white">{diagnosis}</p>
                      ))}
                    </div>
                  </div>
                </div>
                
                <div>
                  <div className="mb-4">
                    <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Contact Information</h3>
                    <div className="mt-1 space-y-1">
                      <p className="text-sm text-gray-900 dark:text-white">{patient.contactInfo.email}</p>
                      <p className="text-sm text-gray-900 dark:text-white">{patient.contactInfo.phone}</p>
                      <p className="text-sm text-gray-900 dark:text-white">{patient.contactInfo.address}</p>
                    </div>
                  </div>
                  <div className="mb-4">
                    <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Emergency Contact</h3>
                    <div className="mt-1 space-y-1">
                      <p className="text-sm text-gray-900 dark:text-white">{patient.emergencyContact.name} ({patient.emergencyContact.relationship})</p>
                      <p className="text-sm text-gray-900 dark:text-white">{patient.emergencyContact.phone}</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="mt-6">
                <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Insurance Information</h3>
                <div className="mt-1 space-y-1">
                  <p className="text-sm text-gray-900 dark:text-white">Provider: {patient.insurance.provider}</p>
                  <p className="text-sm text-gray-900 dark:text-white">Policy Number: {patient.insurance.policyNumber}</p>
                  <p className="text-sm text-gray-900 dark:text-white">Group Number: {patient.insurance.groupNumber}</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
              <h2 className="text-lg font-semibold text-gray-800 dark:text-white">Treatment Progress</h2>
            </div>
            <div className="p-6">
              <div className="space-y-6">
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Anxiety</h3>
                    <span className="text-sm font-medium text-gray-900 dark:text-white">{patient.metrics.anxiety}%</span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                    <div 
                      className="bg-indigo-600 dark:bg-indigo-500 h-2.5 rounded-full" 
                      style={{ width: `${patient.metrics.anxiety}%` }}
                    ></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Depression</h3>
                    <span className="text-sm font-medium text-gray-900 dark:text-white">{patient.metrics.depression}%</span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                    <div 
                      className="bg-blue-600 dark:bg-blue-500 h-2.5 rounded-full" 
                      style={{ width: `${patient.metrics.depression}%` }}
                    ></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Sleep Quality</h3>
                    <span className="text-sm font-medium text-gray-900 dark:text-white">{patient.metrics.sleep}%</span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                    <div 
                      className="bg-purple-600 dark:bg-purple-500 h-2.5 rounded-full" 
                      style={{ width: `${patient.metrics.sleep}%` }}
                    ></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Treatment Adherence</h3>
                    <span className="text-sm font-medium text-gray-900 dark:text-white">{patient.metrics.adherence}%</span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                    <div 
                      className="bg-green-600 dark:bg-green-500 h-2.5 rounded-full" 
                      style={{ width: `${patient.metrics.adherence}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="space-y-6">
          <div className="bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
              <h2 className="text-lg font-semibold text-gray-800 dark:text-white">Sessions</h2>
            </div>
            <div className="p-6">
              <div className="mb-4">
                <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Last Session</h3>
                <p className="mt-1 text-sm text-gray-900 dark:text-white">{formatDate(patient.lastSession)}</p>
              </div>
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Next Session</h3>
                <p className="mt-1 text-sm text-gray-900 dark:text-white">{formatDate(patient.nextSession)}</p>
              </div>
              <Link
                to={`/patients/${patient.id}/history`}
                className="w-full inline-flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800"
              >
                <ClipboardDocumentListIcon className="h-5 w-5 mr-2" />
                View Session History
              </Link>
            </div>
          </div>
          
          <div className="bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
              <h2 className="text-lg font-semibold text-gray-800 dark:text-white">Quick Actions</h2>
            </div>
            <div className="p-6 space-y-4">
              <Link
                to={`/patients/${patient.id}/insights`}
                className="w-full inline-flex items-center justify-center px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm text-sm font-medium text-gray-700 dark:text-gray-200 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800"
              >
                <ChartBarIcon className="h-5 w-5 mr-2 text-indigo-500 dark:text-indigo-400" />
                View AI Insights
              </Link>
              
              <Link
                to={`/patients/${patient.id}/chat`}
                className="w-full inline-flex items-center justify-center px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm text-sm font-medium text-gray-700 dark:text-gray-200 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800"
              >
                <ChatBubbleLeftRightIcon className="h-5 w-5 mr-2 text-indigo-500 dark:text-indigo-400" />
                Chat Analysis
              </Link>
              
              <button
                onClick={() => addNotification({
                  type: 'info',
                  title: 'Coming Soon',
                  message: 'The schedule session feature is coming soon!',
                  autoDismiss: true
                })}
                className="w-full inline-flex items-center justify-center px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm text-sm font-medium text-gray-700 dark:text-gray-200 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800"
              >
                <CalendarIcon className="h-5 w-5 mr-2 text-indigo-500 dark:text-indigo-400" />
                Schedule Session
              </button>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default PatientDetail;