import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  UserIcon, 
  ClockIcon, 
  ChartBarIcon, 
  DocumentTextIcon,
  ArrowUpIcon,
  ArrowDownIcon
} from '@heroicons/react/24/outline';
import { useAuth } from '../context/AuthContext';
import { useNotification } from '../context/NotificationContext';

// Mock data
const mockPatients = [
  { id: 'p1', name: 'Sarah Johnson', diagnosis: ['Generalized Anxiety Disorder', 'Insomnia'], lastSession: '2023-06-15', riskLevel: 'Low' },
  { id: 'p2', name: 'Michael Chen', diagnosis: ['Major Depressive Disorder', 'Social Anxiety Disorder'], lastSession: '2023-06-10', riskLevel: 'Moderate' },
  { id: 'p3', name: 'Emily Rodriguez', diagnosis: ['PTSD', 'Panic Disorder'], lastSession: '2023-06-12', riskLevel: 'Moderate' }
];

const mockUpcomingSessions = [
  { id: 's1', patientId: 'p1', patientName: 'Sarah Johnson', date: '2023-06-22T10:00:00', type: 'Regular Session' },
  { id: 's2', patientId: 'p3', patientName: 'Emily Rodriguez', date: '2023-06-23T11:00:00', type: 'Exposure Therapy' },
  { id: 's3', patientId: 'p2', patientName: 'Michael Chen', date: '2023-06-24T14:00:00', type: 'Regular Session' }
];

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const { addNotification } = useNotification();
  const [patients, setPatients] = useState(mockPatients);
  const [upcomingSessions, setUpcomingSessions] = useState(mockUpcomingSessions);
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    // Simulate loading data
    const timer = setTimeout(() => {
      setIsLoading(false);
      
      // Show welcome notification
      addNotification({
        type: 'info',
        title: 'Welcome back!',
        message: `Hello ${user?.name}, you have ${upcomingSessions.length} upcoming sessions this week.`,
        autoDismiss: true
      });
    }, 1000);
    
    return () => clearTimeout(timer);
  }, [addNotification, user, upcomingSessions.length]);
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };
  
  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
  };
  
  const getRiskLevelClass = (riskLevel: string) => {
    switch (riskLevel.toLowerCase()) {
      case 'high':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      case 'moderate':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      case 'low':
      default:
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
    }
  };
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.3
      }
    }
  };
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
      </div>
    );
  }
  
  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row gap-6">
        <motion.div variants={itemVariants} className="bg-white dark:bg-gray-800 rounded-lg shadow p-6 flex-1">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-indigo-100 dark:bg-indigo-900 text-indigo-600 dark:text-indigo-300">
              <UserIcon className="h-6 w-6" />
            </div>
            <div className="ml-4">
              <h2 className="text-lg font-semibold text-gray-700 dark:text-gray-200">Active Patients</h2>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">{patients.length}</p>
            </div>
          </div>
          <div className="mt-4 flex items-center text-sm">
            <ArrowUpIcon className="h-4 w-4 text-green-500 mr-1" />
            <span className="text-green-500 font-medium">+2 this month</span>
          </div>
        </motion.div>
        
        <motion.div variants={itemVariants} className="bg-white dark:bg-gray-800 rounded-lg shadow p-6 flex-1">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-300">
              <ClockIcon className="h-6 w-6" />
            </div>
            <div className="ml-4">
              <h2 className="text-lg font-semibold text-gray-700 dark:text-gray-200">Upcoming Sessions</h2>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">{upcomingSessions.length}</p>
            </div>
          </div>
          <div className="mt-4 flex items-center text-sm">
            <ArrowUpIcon className="h-4 w-4 text-green-500 mr-1" />
            <span className="text-green-500 font-medium">+1 from last week</span>
          </div>
        </motion.div>
        
        <motion.div variants={itemVariants} className="bg-white dark:bg-gray-800 rounded-lg shadow p-6 flex-1">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-purple-100 dark:bg-purple-900 text-purple-600 dark:text-purple-300">
              <ChartBarIcon className="h-6 w-6" />
            </div>
            <div className="ml-4">
              <h2 className="text-lg font-semibold text-gray-700 dark:text-gray-200">AI Insights</h2>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">12</p>
            </div>
          </div>
          <div className="mt-4 flex items-center text-sm">
            <ArrowUpIcon className="h-4 w-4 text-green-500 mr-1" />
            <span className="text-green-500 font-medium">+5 new insights</span>
          </div>
        </motion.div>
        
        <motion.div variants={itemVariants} className="bg-white dark:bg-gray-800 rounded-lg shadow p-6 flex-1">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-yellow-100 dark:bg-yellow-900 text-yellow-600 dark:text-yellow-300">
              <DocumentTextIcon className="h-6 w-6" />
            </div>
            <div className="ml-4">
              <h2 className="text-lg font-semibold text-gray-700 dark:text-gray-200">Literature Matches</h2>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">24</p>
            </div>
          </div>
          <div className="mt-4 flex items-center text-sm">
            <ArrowUpIcon className="h-4 w-4 text-green-500 mr-1" />
            <span className="text-green-500 font-medium">+8 new papers</span>
          </div>
        </motion.div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div variants={itemVariants} className="bg-white dark:bg-gray-800 rounded-lg shadow">
          <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
            <h2 className="text-lg font-semibold text-gray-800 dark:text-white">Recent Patients</h2>
          </div>
          <div className="divide-y divide-gray-200 dark:divide-gray-700">
            {patients.map(patient => (
              <Link 
                key={patient.id} 
                to={`/patients/${patient.id}`}
                className="block px-6 py-4 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-base font-medium text-gray-800 dark:text-white">{patient.name}</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {patient.diagnosis.join(', ')}
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                      Last session: {formatDate(patient.lastSession)}
                    </p>
                  </div>
                  <div>
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getRiskLevelClass(patient.riskLevel)}`}>
                      {patient.riskLevel}
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
          <div className="px-6 py-4 border-t border-gray-200 dark:border-gray-700">
            <Link 
              to="/patients" 
              className="text-sm font-medium text-indigo-600 dark:text-indigo-400 hover:text-indigo-500 dark:hover:text-indigo-300"
            >
              View all patients →
            </Link>
          </div>
        </motion.div>
        
        <motion.div variants={itemVariants} className="bg-white dark:bg-gray-800 rounded-lg shadow">
          <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
            <h2 className="text-lg font-semibold text-gray-800 dark:text-white">Upcoming Sessions</h2>
          </div>
          <div className="divide-y divide-gray-200 dark:divide-gray-700">
            {upcomingSessions.map(session => (
              <div key={session.id} className="px-6 py-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-base font-medium text-gray-800 dark:text-white">{session.patientName}</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {session.type}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium text-gray-900 dark:text-white">
                      {formatDate(session.date)}
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {formatTime(session.date)}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="px-6 py-4 border-t border-gray-200 dark:border-gray-700">
            <Link 
              to="/calendar" 
              className="text-sm font-medium text-indigo-600 dark:text-indigo-400 hover:text-indigo-500 dark:hover:text-indigo-300"
            >
              View full calendar →
            </Link>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default Dashboard;