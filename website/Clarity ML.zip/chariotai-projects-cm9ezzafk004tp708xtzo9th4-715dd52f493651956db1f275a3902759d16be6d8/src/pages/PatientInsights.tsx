import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  ArrowLeftIcon,
  ArrowPathIcon,
  DocumentTextIcon,
  LightBulbIcon,
  BookOpenIcon
} from '@heroicons/react/24/outline';
import { useNotification } from '../context/NotificationContext';

// Mock data
const mockPatients = {
  'p1': {
    id: 'p1',
    name: 'Sarah Johnson',
    diagnosis: ['Generalized Anxiety Disorder', 'Insomnia']
  },
  'p2': {
    id: 'p2',
    name: 'Michael Chen',
    diagnosis: ['Major Depressive Disorder', 'Social Anxiety Disorder']
  },
  'p3': {
    id: 'p3',
    name: 'Emily Rodriguez',
    diagnosis: ['PTSD', 'Panic Disorder']
  }
};

const mockInsights = {
  'p1': {
    timestamp: '2023-06-16T14:25:00Z',
    insights: "Based on the patient's history, there is a clear pattern of anxiety triggered by work-related stressors, particularly around deadlines and performance evaluations. Sleep disruption appears to both result from and exacerbate anxiety symptoms, creating a feedback loop. Cognitive restructuring techniques have shown the most consistent positive impact, while breathing exercises are less effective during high-stress periods. Recent sessions indicate family dynamics may be an emerging source of stress that warrants further exploration.",
    source: 'openai',
    model: 'gpt-4',
    sentimentTrend: [
      { date: '2023-01', value: 42 },
      { date: '2023-02', value: 38 },
      { date: '2023-03', value: 45 },
      { date: '2023-04', value: 53 },
      { date: '2023-05', value: 58 },
      { date: '2023-06', value: 62 }
    ],
    topicAnalysis: [
      { topic: 'Work stress', percentage: 32 },
      { topic: 'Family relationships', percentage: 24 },
      { topic: 'Sleep issues', percentage: 18 },
      { topic: 'Social anxiety', percentage: 14 },
      { topic: 'Health concerns', percentage: 12 }
    ]
  },
  'p2': {
    timestamp: '2023-06-12T11:30:00Z',
    insights: "Michael's depression appears to be primarily driven by a combination of work dissatisfaction and social isolation. His social anxiety significantly limits his ability to form new connections, creating a reinforcing cycle of isolation and depression. Behavioral activation has shown promising initial results, with mood improvements noted after engagement in previously enjoyed activities. However, cognitive work has been challenging due to strong negative schemas about self-worth being tied to professional achievement. Recent sessions suggest childhood experiences with a highly critical father may be contributing to current perfectionism and fear of judgment.",
    source: 'openai',
    model: 'gpt-4',
    sentimentTrend: [
      { date: '2023-01', value: 28 },
      { date: '2023-02', value: 25 },
      { date: '2023-03', value: 30 },
      { date: '2023-04', value: 35 },
      { date: '2023-05', value: 42 },
      { date: '2023-06', value: 38 }
    ],
    topicAnalysis: [
      { topic: 'Work dissatisfaction', percentage: 35 },
      { topic: 'Social isolation', percentage: 28 },
      { topic: 'Self-criticism', percentage: 22 },
      { topic: 'Family relationships', percentage: 10 },
      { topic: 'Physical health', percentage: 5 }
    ]
  },
  'p3': {
    timestamp: '2023-06-14T09:15:00Z',
    insights: "Emily's PTSD symptoms stem from a car accident 18 months ago, with panic attacks developing approximately 6 months post-trauma. Exposure therapy has shown promising results for reducing avoidance behaviors, particularly around driving and being a passenger in vehicles. Hypervigilance remains a significant issue, especially in high-traffic situations. Panic attacks have decreased in frequency from 4-5 per week to 1-2 per week, with improved ability to implement breathing and grounding techniques when early symptoms emerge. Sleep remains disrupted by trauma-related nightmares approximately 2-3 times per week. Recent sessions indicate growing insight into how hyperarousal is triggered by specific environmental cues.",
    source: 'openai',
    model: 'gpt-4',
    sentimentTrend: [
      { date: '2023-01', value: 30 },
      { date: '2023-02', value: 32 },
      { date: '2023-03', value: 38 },
      { date: '2023-04', value: 45 },
      { date: '2023-05', value: 48 },
      { date: '2023-06', value: 52 }
    ],
    topicAnalysis: [
      { topic: 'Trauma triggers', percentage: 30 },
      { topic: 'Panic symptoms', percentage: 25 },
      { topic: 'Avoidance behaviors', percentage: 20 },
      { topic: 'Sleep disturbances', percentage: 15 },
      { topic: 'Coping strategies', percentage: 10 }
    ]
  }
};

const mockLiterature = {
  'p1': [
    {
      id: 'l1',
      title: 'Cognitive Behavioral Therapy for Generalized Anxiety Disorder: A Meta-Analysis',
      authors: 'Johnson, A., Smith, B., & Williams, C.',
      journal: 'Journal of Anxiety Disorders',
      year: 2021,
      relevance: 92,
      summary: 'This meta-analysis of 24 randomized controlled trials found that CBT is highly effective for GAD, with large effect sizes for worry reduction and moderate effects for sleep improvement. The combination of cognitive restructuring and behavioral techniques showed superior outcomes compared to either approach alone.'
    },
    {
      id: 'l2',
      title: 'Family Dynamics in the Maintenance of Anxiety Disorders: Intergenerational Patterns',
      authors: 'Rodriguez, M., & Thompson, K.',
      journal: 'Family Process',
      year: 2020,
      relevance: 85,
      summary: 'This study examined how family interaction patterns contribute to the maintenance of anxiety disorders in adults. Results indicated that critical parenting styles in childhood predicted heightened sensitivity to criticism in adulthood, with workplace criticism often triggering anxiety responses similar to those experienced in family-of-origin interactions.'
    },
    {
      id: 'l3',
      title: 'Sleep and Anxiety: A Bidirectional Relationship',
      authors: 'Chen, H., & Davis, R.',
      journal: 'Sleep Medicine Reviews',
      year: 2022,
      relevance: 88,
      summary: 'This comprehensive review demonstrates the bidirectional relationship between sleep disturbances and anxiety disorders. The authors present evidence that treating sleep problems can reduce anxiety symptoms, and that cognitive techniques targeting pre-sleep rumination are particularly effective for breaking the anxiety-insomnia cycle.'
    }
  ],
  'p2': [
    {
      id: 'l4',
      title: 'Behavioral Activation for Depression: A Comprehensive Review',
      authors: 'Wilson, J., & Brown, T.',
      journal: 'Clinical Psychology Review',
      year: 2021,
      relevance: 94,
      summary: 'This review of 35 studies found that behavioral activation is highly effective for depression, particularly for patients with comorbid social anxiety. The authors highlight that gradual exposure to social activities combined with pleasant activity scheduling produces better outcomes than activity scheduling alone.'
    },
    {
      id: 'l5',
      title: 'Early Maladaptive Schemas and Depression: The Role of Perfectionism',
      authors: 'Zhang, L., & Anderson, P.',
      journal: 'Cognitive Therapy and Research',
      year: 2020,
      relevance: 89,
      summary: 'This study examined how early maladaptive schemas related to perfectionism mediate the relationship between critical parenting and adult depression. Results showed that schemas related to unrelenting standards and failure were particularly relevant for individuals whose self-worth was contingent on achievement.'
    }
  ],
  'p3': [
    {
      id: 'l6',
      title: 'Prolonged Exposure Therapy for PTSD Following Motor Vehicle Accidents',
      authors: 'Harris, S., & Martinez, J.',
      journal: 'Journal of Traumatic Stress',
      year: 2022,
      relevance: 96,
      summary: 'This randomized controlled trial demonstrated that prolonged exposure therapy significantly reduced PTSD symptoms in survivors of motor vehicle accidents. The study found that a graduated exposure hierarchy focusing first on less triggering aspects of driving (e.g., sitting in a parked car) before progressing to more challenging situations (e.g., highway driving) produced the best outcomes with minimal dropout.'
    },
    {
      id: 'l7',
      title: 'Sleep Disturbances in PTSD: Mechanisms and Treatment Approaches',
      authors: 'Patel, R., & Johnson, K.',
      journal: 'Sleep Medicine',
      year: 2021,
      relevance: 87,
      summary: 'This paper reviews the neurobiological mechanisms underlying trauma-related sleep disturbances and evaluates treatment approaches. The authors found that trauma-focused therapies combined with specific sleep interventions (e.g., imagery rehearsal therapy for nightmares) were more effective than either approach alone.'
    }
  ]
};

const PatientInsights: React.FC = () => {
  const { patientId } = useParams<{ patientId: string }>();
  const { addNotification } = useNotification();
  const [patient, setPatient] = useState<any>(null);
  const [insights, setInsights] = useState<any>(null);
  const [literature, setLiterature] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);
  
  useEffect(() => {
    // Simulate loading data
    const timer = setTimeout(() => {
      if (patientId) {
        const patientData = mockPatients[patientId as keyof typeof mockPatients];
        const insightsData = mockInsights[patientId as keyof typeof mockInsights];
        const literatureData = mockLiterature[patientId as keyof typeof mockLiterature] || [];
        
        if (patientData) {
          setPatient(patientData);
          setInsights(insightsData);
          setLiterature(literatureData);
        }
      }
      
      setIsLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, [patientId]);
  
  const handleGenerateInsights = () => {
    setIsGenerating(true);
    
    // Simulate generating new insights
    setTimeout(() => {
      setIsGenerating(false);
      
      addNotification({
        type: 'success',
        title: 'Insights Generated',
        message: 'New insights have been generated successfully.',
        autoDismiss: true
      });
    }, 3000);
  };
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
  };
  
  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
  };
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        duration: 0.3
      }
    }
  };
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
      </div>
    );
  }
  
  if (!patient || !insights) {
    return (
      <div className="flex flex-col items-center justify-center h-full">
        <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-2">Data Not Found</h2>
        <p className="text-gray-600 dark:text-gray-400 mb-4">The requested patient or insights could not be found.</p>
        <Link
          to="/patients"
          className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800"
        >
          <ArrowLeftIcon className="h-5 w-5 mr-2" />
          Back to Patients
        </Link>
      </div>
    );
  }
  
  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-6"
    >
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center">
          <Link
            to={`/patients/${patientId}`}
            className="mr-4 p-2 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
          >
            <ArrowLeftIcon className="h-5 w-5" />
          </Link>
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{patient.name} - Insights</h1>
            <p className="text-sm text-gray-500 dark:text-gray-400">{patient.diagnosis.join(', ')}</p>
          </div>
        </div>
        
        <button
          onClick={handleGenerateInsights}
          disabled={isGenerating}
          className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isGenerating ? (
            <>
              <ArrowPathIcon className="h-5 w-5 mr-2 animate-spin" />
              Generating...
            </>
          ) : (
            <>
              <LightBulbIcon className="h-5 w-5 mr-2" />
              Generate New Insights
            </>
          )}
        </button>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
              <h2 className="text-lg font-semibold text-gray-800 dark:text-white">AI-Generated Insights</h2>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                Generated on {formatDate(insights.timestamp)} at {formatTime(insights.timestamp)} using {insights.model}
              </p>
            </div>
            <div className="p-6">
              <p className="text-gray-900 dark:text-white whitespace-pre-line">{insights.insights}</p>
            </div>
          </div>
          
          <div className="bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
              <h2 className="text-lg font-semibold text-gray-800 dark:text-white">Sentiment Trend</h2>
            </div>
            <div className="p-6">
              <div className="h-64 flex items-end justify-between space-x-2">
                {insights.sentimentTrend.map((item: any, index: number) => (
                  <div key={index} className="flex flex-col items-center flex-1">
                    <div 
                      className="w-full bg-indigo-500 dark:bg-indigo-600 rounded-t"
                      style={{ height: `${item.value}%` }}
                    ></div>
                    <span className="text-xs text-gray-500 dark:text-gray-400 mt-1">{item.date.split('-')[1]}</span>
                  </div>
                ))}
              </div>
              <div className="mt-4 flex justify-between">
                <span className="text-sm font-medium text-gray-500 dark:text-gray-400">January</span>
                <span className="text-sm font-medium text-gray-500 dark:text-gray-400">June</span>
              </div>
              <div className="mt-2 text-center">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Sentiment Score (higher is better)</span>
              </div>
            </div>
          </div>
          
          <div className="bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
              <h2 className="text-lg font-semibold text-gray-800 dark:text-white">Topic Analysis</h2>
            </div>
            <div className="p-6">
              <div className="space-y-4">
                {insights.topicAnalysis.map((item: any, index: number) => (
                  <div key={index}>
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{item.topic}</span>
                      <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{item.percentage}%</span>
                    </div>
                    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                      <div 
                        className="bg-indigo-600 dark:bg-indigo-500 h-2.5 rounded-full" 
                        style={{ width: `${item.percentage}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
        
        <div className="space-y-6">
          <div className="bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
              <h2 className="text-lg font-semibold text-gray-800 dark:text-white">Relevant Literature</h2>
            </div>
            <div className="divide-y divide-gray-200 dark:divide-gray-700">
              {literature.map((paper) => (
                <div key={paper.id} className="p-6">
                  <div className="flex items-start">
                    <div className="flex-shrink-0 mt-1">
                      <BookOpenIcon className="h-5 w-5 text-indigo-500 dark:text-indigo-400" />
                    </div>
                    <div className="ml-3">
                      <h3 className="text-base font-medium text-gray-900 dark:text-white">{paper.title}</h3>
                      <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{paper.authors}</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">{paper.journal}, {paper.year}</p>
                      <div className="mt-2 flex items-center">
                        <span className="text-xs font-medium text-indigo-600 dark:text-indigo-400 bg-indigo-100 dark:bg-indigo-900 px-2 py-0.5 rounded">
                          {paper.relevance}% Relevance
                        </span>
                      </div>
                      <p className="mt-2 text-sm text-gray-700 dark:text-gray-300">{paper.summary}</p>
                    </div>
                  </div>
                </div>
              ))}
              
              {literature.length === 0 && (
                <div className="p-6 text-center">
                  <p className="text-gray-500 dark:text-gray-400">No relevant literature found.</p>
                </div>
              )}
            </div>
            <div className="px-6 py-4 border-t border-gray-200 dark:border-gray-700">
              <Link 
                to="/literature" 
                className="text-sm font-medium text-indigo-600 dark:text-indigo-400 hover:text-indigo-500 dark:hover:text-indigo-300"
              >
                Search literature →
              </Link>
            </div>
          </div>
          
          <div className="bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
              <h2 className="text-lg font-semibold text-gray-800 dark:text-white">Treatment Recommendations</h2>
            </div>
            <div className="p-6">
              <ul className="space-y-3 text-sm text-gray-700 dark:text-gray-300">
                {patient.id === 'p1' && (
                  <>
                    <li className="flex items-start">
                      <span className="flex-shrink-0 h-1.5 w-1.5 rounded-full bg-indigo-500 mt-1.5 mr-2"></span>
                      <span>Continue cognitive restructuring with focus on work performance anxiety</span>
                    </li>
                    <li className="flex items-start">
                      <span className="flex-shrink-0 h-1.5 w-1.5 rounded-full bg-indigo-500 mt-1.5 mr-2"></span>
                      <span>Explore family dynamics, particularly relationship with mother</span>
                    </li>
                    <li className="flex items-start">
                      <span className="flex-shrink-0 h-1.5 w-1.5 rounded-full bg-indigo-500 mt-1.5 mr-2"></span>
                      <span>Maintain sleep hygiene practices and progressive muscle relaxation</span>
                    </li>
                    <li className="flex items-start">
                      <span className="flex-shrink-0 h-1.5 w-1.5 rounded-full bg-indigo-500 mt-1.5 mr-2"></span>
                      <span>Consider mindfulness-based stress reduction to address physical anxiety symptoms</span>
                    </li>
                  </>
                )}
                
                {patient.id === 'p2' && (
                  <>
                    <li className="flex items-start">
                      <span className="flex-shrink-0 h-1.5 w-1.5 rounded-full bg-indigo-500 mt-1.5 mr-2"></span>
                      <span>Continue behavioral activation with gradual increase in social activities</span>
                    </li>
                    <li className="flex items-start">
                      <span className="flex-shrink-0 h-1.5 w-1.5 rounded-full bg-indigo-500 mt-1.5 mr-2"></span>
                      <span>Address perfectionism and self-worth schemas through schema therapy</span>
                    </li>
                    <li className="flex items-start">
                      <span className="flex-shrink-0 h-1.5 w-1.5 rounded-full bg-indigo-500 mt-1.5 mr-2"></span>
                      <span>Explore childhood experiences with critical father and their impact on current functioning</span>
                    </li>
                    <li className="flex items-start">
                      <span className="flex-shrink-0 h-1.5 w-1.5 rounded-full bg-indigo-500 mt-1.5 mr-2"></span>
                      <span>Consider sleep interventions for early morning awakening</span>
                    </li>
                  </>
                )}
                
                {patient.id === 'p3' && (
                  <>
                    <li className="flex items-start">
                      <span className="flex-shrink-0 h-1.5 w-1.5 rounded-full bg-indigo-500 mt-1.5 mr-2"></span>
                      <span>Continue exposure therapy with gradual progression through driving hierarchy</span>
                    </li>
                    <li className="flex items-start">
                      <span className="flex-shrink-0 h-1.5 w-1.5 rounded-full bg-indigo-500 mt-1.5 mr-2"></span>
                      <span>Complete trauma narrative processing</span>
                    </li>
                    <li className="flex items-start">
                      <span className="flex-shrink-0 h-1.5 w-1.5 rounded-full bg-indigo-500 mt-1.5 mr-2"></span>
                      <span>Address sleep disturbances with imagery rehearsal therapy for nightmares</span>
                    </li>
                    <li className="flex items-start">
                      <span className="flex-shrink-0 h-1.5 w-1.5 rounded-full bg-indigo-500 mt-1.5 mr-2"></span>
                      <span>Continue grounding and panic management skills practice</span>
                    </li>
                  </>
                )}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default PatientInsights;