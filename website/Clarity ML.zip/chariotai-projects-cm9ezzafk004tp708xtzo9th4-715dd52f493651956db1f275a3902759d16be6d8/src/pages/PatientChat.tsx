import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  ArrowLeftIcon,
  ArrowPathIcon,
  ChatBubbleLeftRightIcon,
  UserIcon,
  UserCircleIcon,
  PaperAirplaneIcon
} from '@heroicons/react/24/outline';
import { useNotification } from '../context/NotificationContext';

// Mock data
const mockPatients = {
  'p1': {
    id: 'p1',
    name: 'Sarah Johnson',
    diagnosis: ['Generalized Anxiety Disorder', 'Insomnia']
  },
  'p2': {
    id: 'p2',
    name: 'Michael Chen',
    diagnosis: ['Major Depressive Disorder', 'Social Anxiety Disorder']
  },
  'p3': {
    id: 'p3',
    name: 'Emily Rodriguez',
    diagnosis: ['PTSD', 'Panic Disorder']
  }
};

const mockChats = {
  'p1': [
    {
      id: 'c1',
      date: '2023-06-15T10:30:00Z',
      messages: [
        { role: 'therapist', content: "Hello Sarah, how have you been feeling since our last session?" },
        { role: 'patient', content: "Not great, to be honest. Work has been really stressful. My boss gave me a big project with an impossible deadline, and I've been having trouble sleeping again." },
        { role: 'therapist', content: "I'm sorry to hear that. Can you tell me more about what's happening with work and how it's affecting your sleep?" },
        { role: 'patient', content: "It's this new project. I have to present to the executive team next week, and I'm worried I'll mess it up. I keep waking up at 3 AM with my mind racing about all the things that could go wrong. Then I can't get back to sleep." },
        { role: 'therapist', content: "That sounds really difficult. Have you been practicing any of the cognitive restructuring techniques we discussed for those nighttime worry thoughts?" },
        { role: 'patient', content: "I tried, but it's hard when it's the middle of the night. I keep thinking that if I fail at this presentation, it will prove I'm not good enough for this job." },
        { role: 'therapist', content: "I understand. Those thoughts can be very powerful, especially at night. Let's work on some specific strategies for addressing those thoughts about the presentation. What's the worst thing that could happen if it doesn't go perfectly?" },
        { role: 'patient', content: "I guess I'm afraid they'll think I'm incompetent and eventually I'll lose my job." },
        { role: 'therapist', content: "And if that happened - which is unlikely - what would that mean to you?" },
        { role: 'patient', content: "That I'm a failure. That I can't handle responsibility. That I've let everyone down." },
        { role: 'therapist', content: "Those are big fears. I'm wondering if we can examine some of the evidence for and against these thoughts. What evidence do you have that you're competent at your job?" }
      ],
      analysis: {
        patientConcerns: [
          "Work stress - presentation anxiety",
          "Sleep disruption",
          "Fear of failure",
          "Catastrophic thinking"
        ],
        therapeuticApproaches: [
          "Cognitive restructuring",
          "Evidence examination",
          "Downward arrow technique"
        ],
        keyInsights: "Patient shows classic catastrophic thinking pattern around work performance. Core belief about being 'not good enough' is triggered by evaluation situations. Sleep disruption is both a result of and contributor to anxiety symptoms."
      }
    },
    {
      id: 'c2',
      date: '2023-06-01T10:30:00Z',
      messages: [
        { role: 'therapist', content: "Hi Sarah, how has your week been?" },
        { role: 'patient', content: "It's been okay. I've been trying those breathing exercises you suggested, but I'm not sure they're helping much." },
        { role: 'therapist', content: "Thanks for trying them. Can you tell me more about when you're using them and what you're noticing?" },
        { role: 'patient', content: "I've been doing them at my desk when I start feeling overwhelmed, but it's hard to focus with everything going on around me. And sometimes I feel like people are watching me." },
        { role: 'therapist', content: "That makes sense. It can be challenging to practice new skills in busy environments. Would it be possible to find a quieter place, maybe a break room or even a bathroom stall, to practice for a few minutes?" },
        { role: 'patient', content: "I could try that. There's a small conference room that's usually empty." },
        { role: 'therapist', content: "That sounds perfect. How about your sleep this week?" },
        { role: 'patient', content: "Still not great. I'm falling asleep okay but waking up around 2 or 3 and then my mind starts racing." },
        { role: 'therapist', content: "What kinds of thoughts come up when you wake up?" },
        { role: 'patient', content: "Usually work stuff. Deadlines, emails I need to send, presentations I'm worried about. Sometimes I start thinking about my mom too." },
        { role: 'therapist', content: "Your mom? Can you tell me more about those thoughts?" },
        { role: 'patient', content: "Just... I know she's going to ask about my promotion when I see her next weekend, and I'm dreading it. She always has such high expectations." }
      ],
      analysis: {
        patientConcerns: [
          "Difficulty implementing coping strategies",
          "Sleep maintenance insomnia",
          "Work stress",
          "Family pressure"
        ],
        therapeuticApproaches: [
          "Problem-solving barriers to skill use",
          "Sleep hygiene",
          "Exploration of family dynamics"
        ],
        keyInsights: "Patient is making efforts to implement coping strategies but facing practical barriers. Family dynamics emerging as potential contributor to performance anxiety. Sleep disruption pattern typical of anxiety-related insomnia."
      }
    }
  ],
  'p2': [
    {
      id: 'c1',
      date: '2023-06-10T14:00:00Z',
      messages: [
        { role: 'therapist', content: "Hello Michael, how have you been since our last session?" },
        { role: 'patient', content: "Not good. I got a bad performance review at work yesterday." },
        { role: 'therapist', content: "I'm sorry to hear that. That sounds difficult. Can you tell me more about what happened?" },
        { role: 'patient', content: "My manager said I'm not being proactive enough and that my communication needs improvement. It just confirms what I already know - I'm not good enough." },
        { role: 'therapist', content: "That feedback sounds challenging to hear. I'm noticing that you're interpreting it as evidence that you're 'not good enough.' I wonder if we could explore that thought a bit more?" },
        { role: 'patient', content: "What's there to explore? It's pretty clear. I've been at this company for five years and I'm still in the same position while others have been promoted." },
        { role: 'therapist', content: "You're feeling stuck and seeing this review as confirmation of a broader pattern. I'm curious, was there anything positive in the review?" },
        { role: 'patient', content: "She said my technical skills are strong and that I'm reliable. But that doesn't really matter if I can't communicate well enough." },
        { role: 'therapist', content: "So there were some strengths identified too. When you say 'that doesn't really matter,' I'm wondering if you might be discounting the positives and focusing primarily on the criticism?" },
        { role: 'patient', content: "Maybe. It's just... my dad always said that if you're not moving up, you're failing. He never accepted anything less than excellence." },
        { role: 'therapist', content: "That's a really high standard to hold yourself to. It sounds like your father's voice is quite present in how you evaluate yourself. How does that impact you?" }
      ],
      analysis: {
        patientConcerns: [
          "Negative self-evaluation",
          "Work performance concerns",
          "All-or-nothing thinking",
          "Internalized parental criticism"
        ],
        therapeuticApproaches: [
          "Cognitive restructuring",
          "Exploring family of origin issues",
          "Identifying cognitive distortions"
        ],
        keyInsights: "Patient shows strong negative self-evaluation triggered by work criticism. Clear pattern of discounting positives while magnifying negatives. Connection between current response to criticism and childhood experiences with critical father emerging as important theme."
      }
    }
  ],
  'p3': [
    {
      id: 'c1',
      date: '2023-06-12T11:00:00Z',
      messages: [
        { role: 'therapist', content: "Hi Emily, how has your week been?" },
        { role: 'patient', content: "Better than last week. I did the driving exposure we talked about." },
        { role: 'therapist', content: "That's great to hear! Can you tell me more about how that went?" },
        { role: 'patient', content: "I drove on the highway for about 15 minutes. My heart was racing at first, but I used the breathing techniques, and it got a bit easier." },
        { role: 'therapist', content: "That's excellent progress. How would you rate your anxiety during the drive on a scale of 0-10?" },
        { role: 'patient', content: "It started around an 8, but went down to maybe a 6 by the end." },
        { role: 'therapist', content: "That's a meaningful reduction. What thoughts came up during the drive?" },
        { role: 'patient', content: "At first, the usual - that a car would hit me from behind, that I'd freeze up and cause an accident. But I kept reminding myself that I was safe, that I've driven thousands of times before the accident." },
        { role: 'therapist', content: "You're doing a great job implementing the cognitive strategies alongside the exposure. Did anything unexpected happen during the drive?" },
        { role: 'patient', content: "Actually, yes. A car backfired near me when I was at work yesterday, and I had a panic attack. But it was shorter than usual - maybe 10 minutes instead of half an hour." },
        { role: 'therapist', content: "I'm sorry you experienced that, but it's encouraging that it was shorter. What did you do differently this time?" },
        { role: 'patient', content: "I recognized what was happening sooner and started the grounding techniques right away. Counting objects I could see, then things I could hear, and so on." }
      ],
      analysis: {
        patientConcerns: [
          "Driving anxiety",
          "Trauma triggers",
          "Panic symptoms",
          "Hypervigilance"
        ],
        therapeuticApproaches: [
          "Exposure therapy",
          "Cognitive restructuring",
          "Grounding techniques",
          "Symptom monitoring"
        ],
        keyInsights: "Patient showing good progress with exposure hierarchy and implementing cognitive strategies. Improved response to panic trigger indicates developing mastery of coping skills. Continued work on trauma processing alongside exposure likely to be beneficial."
      }
    }
  ]
};

interface Message {
  role: 'therapist' | 'patient';
  content: string;
}

interface ChatSession {
  id: string;
  date: string;
  messages: Message[];
  analysis: {
    patientConcerns: string[];
    therapeuticApproaches: string[];
    keyInsights: string;
  };
}

const PatientChat: React.FC = () => {
  const { patientId } = useParams<{ patientId: string }>();
  const { addNotification } = useNotification();
  const [patient, setPatient] = useState<any>(null);
  const [chatSessions, setChatSessions] = useState<ChatSession[]>([]);
  const [selectedChat, setSelectedChat] = useState<ChatSession | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [newMessage, setNewMessage] = useState('');
  
  useEffect(() => {
    // Simulate loading data
    const timer = setTimeout(() => {
      if (patientId) {
        const patientData = mockPatients[patientId as keyof typeof mockPatients];
        const chatData = mockChats[patientId as keyof typeof mockChats] || [];
        
        if (patientData) {
          setPatient(patientData);
          setChatSessions(chatData);
          
          if (chatData.length > 0) {
            setSelectedChat(chatData[0]);
          }
        }
      }
      
      setIsLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, [patientId]);
  
  const handleSelectChat = (chat: ChatSession) => {
    setSelectedChat(chat);
  };
  
  const handleAnalyzeChat = () => {
    setIsAnalyzing(true);
    
    // Simulate analyzing chat
    setTimeout(() => {
      setIsAnalyzing(false);
      
      addNotification({
        type: 'success',
        title: 'Analysis Complete',
        message: 'Chat analysis has been updated successfully.',
        autoDismiss: true
      });
    }, 3000);
  };
  
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newMessage.trim() || !selectedChat) return;
    
    // Add message to selected chat
    const updatedChat = {
      ...selectedChat,
      messages: [
        ...selectedChat.messages,
        { role: 'therapist', content: newMessage.trim() }
      ]
    };
    
    setSelectedChat(updatedChat);
    
    // Update chat sessions
    const updatedSessions = chatSessions.map(chat => 
      chat.id === selectedChat.id ? updatedChat : chat
    );
    
    setChatSessions(updatedSessions);
    setNewMessage('');
    
    // Simulate patient response
    setTimeout(() => {
      const patientResponses = [
        "I'll try to remember that. It's just hard sometimes when I'm in the moment.",
        "That makes sense. I hadn't thought about it that way before.",
        "I'm not sure. I'll need to think about that more.",
        "Yes, exactly. That's how I've been feeling.",
        "I'll try those techniques this week and let you know how it goes."
      ];
      
      const randomResponse = patientResponses[Math.floor(Math.random() * patientResponses.length)];
      
      const chatWithResponse = {
        ...updatedChat,
        messages: [
          ...updatedChat.messages,
          { role: 'patient', content: randomResponse }
        ]
      };
      
      setSelectedChat(chatWithResponse);
      
      // Update chat sessions
      const sessionsWithResponse = updatedSessions.map(chat => 
        chat.id === selectedChat.id ? chatWithResponse : chat
      );
      
      setChatSessions(sessionsWithResponse);
    }, 2000);
  };
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
  };
  
  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
  };
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        duration: 0.3
      }
    }
  };
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
      </div>
    );
  }
  
  if (!patient) {
    return (
      <div className="flex flex-col items-center justify-center h-full">
        <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-2">Patient Not Found</h2>
        <p className="text-gray-600 dark:text-gray-400 mb-4">The requested patient could not be found.</p>
        <Link
          to="/patients"
          className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800"
        >
          <ArrowLeftIcon className="h-5 w-5 mr-2" />
          Back to Patients
        </Link>
      </div>
    );
  }
  
  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-6"
    >
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center">
          <Link
            to={`/patients/${patientId}`}
            className="mr-4 p-2 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
          >
            <ArrowLeftIcon className="h-5 w-5" />
          </Link>
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{patient.name} - Chat Analysis</h1>
            <p className="text-sm text-gray-500 dark:text-gray-400">{patient.diagnosis.join(', ')}</p>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-12rem)]">
        <div className="bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
            <h2 className="text-lg font-semibold text-gray-800 dark:text-white">Chat Sessions</h2>
          </div>
          <div className="overflow-y-auto h-[calc(100%-4rem)]">
            {chatSessions.length === 0 ? (
              <div className="p-6 text-center">
                <p className="text-gray-500 dark:text-gray-400">No chat sessions found.</p>
              </div>
            ) : (
              <div className="divide-y divide-gray-200 dark:divide-gray-700">
                {chatSessions.map((chat) => (
                  <div 
                    key={chat.id}
                    className={`px-6 py-4 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors ${
                      selectedChat?.id === chat.id ? 'bg-indigo-50 dark:bg-indigo-900/20' : ''
                    }`}
                    onClick={() => handleSelectChat(chat)}
                  >
                    <div className="flex items-center">
                      <div className="p-2 rounded-full bg-indigo-100 dark:bg-indigo-900 text-indigo-600 dark:text-indigo-300 mr-4">
                        <ChatBubbleLeftRightIcon className="h-5 w-5" />
                      </div>
                      <div>
                        <h3 className="text-base font-medium text-gray-900 dark:text-white">Session</h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          {formatDate(chat.date)} at {formatTime(chat.date)}
                        </p>
                        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                          {chat.messages.length} messages
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
        
        <div className="lg:col-span-2 grid grid-rows-[auto_1fr_auto] bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden h-full">
          {selectedChat ? (
            <>
              <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
                <h2 className="text-lg font-semibold text-gray-800 dark:text-white">
                  Session: {formatDate(selectedChat.date)}
                </h2>
                <button
                  onClick={handleAnalyzeChat}
                  disabled={isAnalyzing}
                  className="inline-flex items-center px-3 py-1.5 border border-transparent rounded-md text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isAnalyzing ? (
                    <>
                      <ArrowPathIcon className="h-4 w-4 mr-1.5 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <ArrowPathIcon className="h-4 w-4 mr-1.5" />
                      Analyze
                    </>
                  )}
                </button>
              </div>
              
              <div className="overflow-y-auto p-6 space-y-4">
                {selectedChat.messages.map((message, index) => (
                  <div 
                    key={index}
                    className={`flex ${message.role === 'therapist' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div className={`flex max-w-[80%] ${message.role === 'therapist' ? 'flex-row-reverse' : ''}`}>
                      <div className={`flex-shrink-0 h-10 w-10 rounded-full flex items-center justify-center ${
                        message.role === 'therapist' 
                          ? 'bg-indigo-100 dark:bg-indigo-900 text-indigo-600 dark:text-indigo-300 ml-3' 
                          : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 mr-3'
                      }`}>
                        {message.role === 'therapist' ? (
                          <UserCircleIcon className="h-6 w-6" />
                        ) : (
                          <UserIcon className="h-6 w-6" />
                        )}
                      </div>
                      <div className={`rounded-lg px-4 py-2 ${
                        message.role === 'therapist' 
                          ? 'bg-indigo-100 dark:bg-indigo-900 text-gray-800 dark:text-white' 
                          : 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-white'
                      }`}>
                        <p className="text-sm">{message.content}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="px-6 py-4 border-t border-gray-200 dark:border-gray-700">
                <form onSubmit={handleSendMessage} className="flex items-center">
                  <input
                    type="text"
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder="Type a message..."
                    className="flex-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-gray-700 dark:text-white"
                  />
                  <button
                    type="submit"
                    disabled={!newMessage.trim()}
                    className="ml-3 inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <PaperAirplaneIcon className="h-5 w-5" />
                  </button>
                </form>
              </div>
            </>
          ) : (
            <div className="flex items-center justify-center h-full">
              <div className="text-center">
                <ChatBubbleLeftRightIcon className="h-12 w-12 text-gray-400 dark:text-gray-600 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 dark:text-white">No Chat Selected</h3>
                <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                  Select a chat session from the list to view the conversation.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
      
      {selectedChat && (
        <div className="bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
            <h2 className="text-lg font-semibold text-gray-800 dark:text-white">AI Analysis</h2>
          </div>
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <h3 className="text-base font-medium text-gray-900 dark:text-white mb-3">Patient Concerns</h3>
                <ul className="space-y-2">
                  {selectedChat.analysis.patientConcerns.map((concern, index) => (
                    <li key={index} className="flex items-start">
                      <span className="flex-shrink-0 h-1.5 w-1.5 rounded-full bg-indigo-500 mt-1.5 mr-2"></span>
                      <span className="text-sm text-gray-700 dark:text-gray-300">{concern}</span>
                    </li>
                  ))}
                </ul>
              </div>
              
              <div>
                <h3 className="text-base font-medium text-gray-900 dark:text-white mb-3">Therapeutic Approaches</h3>
                <ul className="space-y-2">
                  {selectedChat.analysis.therapeuticApproaches.map((approach, index) => (
                    <li key={index} className="flex items-start">
                      <span className="flex-shrink-0 h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                      <span className="text-sm text-gray-700 dark:text-gray-300">{approach}</span>
                    </li>
                  ))}
                </ul>
              </div>
              
              <div>
                <h3 className="text-base font-medium text-gray-900 dark:text-white mb-3">Key Insights</h3>
                <p className="text-sm text-gray-700 dark:text-gray-300">{selectedChat.analysis.keyInsights}</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </motion.div>
  );
};

export default PatientChat;