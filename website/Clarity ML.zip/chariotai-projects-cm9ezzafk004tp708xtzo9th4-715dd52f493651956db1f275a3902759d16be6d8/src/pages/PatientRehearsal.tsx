import { useState, useEffect, useRef } from "react";
import { useParams } from "react-router-dom";
import { motion } from "framer-motion";
import { useTheme } from "../utils/themeContext";
import { getPatientById } from "../utils/patientData";

function PatientRehearsal() {
  const { patientId, id: therapistId } = useParams<{ patientId: string; id: string }>();
  const [patient, setPatient] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");
  const [chatHistory, setChatHistory] = useState<any[]>([]);
  const [approach, setApproach] = useState<string>("cbt");
  const [nudgesEnabled, setNudgesEnabled] = useState(false);
  const [focusPoints, setFocusPoints] = useState("");
  const [showFocusPointsModal, setShowFocusPointsModal] = useState(false);
  const [currentNudge, setCurrentNudge] = useState<string | null>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const { getColor } = useTheme();
  
  // Get colors from theme
  const primaryColor = `text-${getColor('primary')}`;
  const primaryBg = `bg-${getColor('primary')}`;
  const secondaryColor = `text-${getColor('secondary')}`;
  const secondaryBg = `bg-${getColor('secondary')}`;

  useEffect(() => {
    // Fetch patient data
    if (patientId) {
      const patientData = getPatientById(patientId);
      if (patientData) {
        setPatient(patientData);
        
        // Initialize chat with context
        setChatHistory([
          { 
            id: 1, 
            sender: "system", 
            message: `Rehearsal started with simulated patient ${patientData.name}`, 
            timestamp: new Date().toISOString() 
          },
          { 
            id: 2, 
            sender: "patient", 
            message: `Hello, doctor. I'm here for my appointment today.`, 
            timestamp: new Date().toISOString() 
          },
        ]);
      }
      setLoading(false);
    }
  }, [patientId]);

  useEffect(() => {
    // Scroll to bottom when chat history updates
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [chatHistory]);

  const toggleNudges = () => {
    setNudgesEnabled(!nudgesEnabled);
    
    // Add system message about nudges
    if (!nudgesEnabled) {
      setChatHistory(prev => [
        ...prev, 
        {
          id: prev.length + 1,
          sender: "system",
          message: "Clarity Nudges enabled - you'll receive real-time suggestions during the conversation",
          timestamp: new Date().toISOString()
        }
      ]);
    } else {
      setChatHistory(prev => [
        ...prev, 
        {
          id: prev.length + 1,
          sender: "system",
          message: "Clarity Nudges disabled",
          timestamp: new Date().toISOString()
        }
      ]);
      setCurrentNudge(null);
    }
  };

  const handleSaveFocusPoints = () => {
    setShowFocusPointsModal(false);
    
    // Add system message about focus points
    if (focusPoints.trim()) {
      setChatHistory(prev => [
        ...prev, 
        {
          id: prev.length + 1,
          sender: "system",
          message: `Focus points set: ${focusPoints}`,
          timestamp: new Date().toISOString()
        }
      ]);
    }
  };

  const generateNudge = (patientMessage: string) => {
    // In a real app, this would call an LLM API
    // Here we'll simulate with some predefined nudges based on the approach
    
    if (approach === "cbt") {
      if (patientMessage.toLowerCase().includes("anxious") || patientMessage.toLowerCase().includes("anxiety")) {
        setCurrentNudge("Try exploring the specific thoughts behind their anxiety. Ask: 'What thoughts go through your mind when you feel anxious?'");
      } else if (patientMessage.toLowerCase().includes("thought") || patientMessage.toLowerCase().includes("think")) {
        setCurrentNudge("Good opportunity to identify cognitive distortions. Consider asking: 'Is there evidence that supports or contradicts this thought?'");
      } else {
        setCurrentNudge("Consider using Socratic questioning to help them examine their beliefs. Try: 'What would you tell a friend who was in this situation?'");
      }
    } else if (approach === "psychodynamic") {
      setCurrentNudge("Notice the connection to childhood experiences. Consider exploring: 'How might this relate to your early relationships?'");
    } else {
      setCurrentNudge("Bring attention back to the present moment. Try: 'What sensations are you noticing in your body right now as you talk about this?'");
    }
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    
    // Add message to chat history
    const newMessage = {
      id: chatHistory.length + 1,
      sender: "therapist",
      message: message,
      timestamp: new Date().toISOString()
    };
    
    setChatHistory([...chatHistory, newMessage]);
    setMessage("");
    
    // Simulate patient response (in a real app, this would call an LLM API)
    setTimeout(() => {
      let responseMessage;
      
      // Generate different responses based on the therapeutic approach and message content
      if (approach === "cbt") {
        if (message.toLowerCase().includes("feel") || message.toLowerCase().includes("emotion")) {
          responseMessage = {
            id: chatHistory.length + 2,
            sender: "patient",
            message: `I've been feeling really anxious lately, especially at work. I keep thinking my boss is going to fire me even though there's no evidence of that. I know it's probably irrational, but I can't stop the thoughts.`,
            timestamp: new Date().toISOString()
          };
        } else if (message.toLowerCase().includes("thought") || message.toLowerCase().includes("think")) {
          responseMessage = {
            id: chatHistory.length + 2,
            sender: "patient",
            message: `My thoughts are usually like "I'm going to mess up" or "Everyone is judging me." I guess when you put it that way, I don't have any real evidence that these thoughts are true. It's just what my mind jumps to.`,
            timestamp: new Date().toISOString()
          };
        } else {
          responseMessage = {
            id: chatHistory.length + 2,
            sender: "patient",
            message: `I tried that breathing exercise you suggested last time. It helped a little bit when I was feeling overwhelmed. But I still had trouble falling asleep last night because my mind was racing with worries.`,
            timestamp: new Date().toISOString()
          };
        }
      } else if (approach === "psychodynamic") {
        responseMessage = {
          id: chatHistory.length + 2,
          sender: "patient",
          message: `You know, that reminds me of how my mother used to react when I was upset as a child. She would always tell me to just get over it and not express my feelings. I wonder if that's why I have such a hard time talking about my emotions now.`,
          timestamp: new Date().toISOString()
        };
      } else {
        responseMessage = {
          id: chatHistory.length + 2,
          sender: "patient",
          message: `I'm trying to be more present like we discussed, but it's hard. My mind keeps wandering to all the things I need to do and all the ways things could go wrong. How do I stay in the moment when everything feels so overwhelming?`,
          timestamp: new Date().toISOString()
        };
      }
      
      setChatHistory(prev => [...prev, responseMessage]);
      
      // Generate nudge if enabled
      if (nudgesEnabled) {
        generateNudge(responseMessage.message);
      }
    }, 1000);
  };

  const handleApproachChange = (newApproach: string) => {
    setApproach(newApproach);
    
    // Add system message about approach change
    setChatHistory(prev => [
      ...prev, 
      {
        id: prev.length + 1,
        sender: "system",
        message: `Switched to ${newApproach === "cbt" ? "Cognitive Behavioral Therapy" : newApproach === "psychodynamic" ? "Psychodynamic Therapy" : "Mindfulness-Based Therapy"} approach`,
        timestamp: new Date().toISOString()
      }
    ]);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className={`animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-${getColor('primary')}`}></div>
      </div>
    );
  }

  if (!patient) {
    return (
      <div className="space-y-6">
        <h1 className={`text-3xl font-bold ${primaryColor} mb-6`}>Patient Rehearsal</h1>
        <div className="bg-white p-6 rounded-lg shadow-md text-center">
          <p className="text-gray-600">Patient not found. Please select a patient from the dashboard.</p>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="h-[calc(100vh-200px)] flex flex-col"
    >
      <div className="bg-white rounded-t-lg shadow-md p-4 border-b border-gray-200">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-xl font-semibold text-gray-800">
              Rehearse Conversation with {patient?.name}
            </h2>
            <p className="text-sm text-gray-500">
              Practice therapeutic approaches with a simulated patient based on their history
            </p>
          </div>
          
          <div className="flex space-x-4">
            <button 
              onClick={() => setShowFocusPointsModal(true)}
              className="px-3 py-1 text-sm rounded-md bg-gray-100 text-gray-700 hover:bg-gray-200 transition-colors flex items-center"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
              </svg>
              Set Focus Points
            </button>
            
            <div className="flex items-center">
              <span className="text-sm text-gray-700 mr-2">Clarity Nudges</span>
              <button 
                onClick={toggleNudges}
                className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none ${
                  nudgesEnabled ? primaryBg : 'bg-gray-300'
                }`}
              >
                <span
                  className={`inline-block w-4 h-4 transform transition-transform bg-white rounded-full ${
                    nudgesEnabled ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
            
            <div className="flex space-x-2">
              <button 
                onClick={() => handleApproachChange("cbt")}
                className={`px-3 py-1 text-sm rounded-md transition-colors ${
                  approach === "cbt" 
                    ? `${primaryBg} text-white` 
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                CBT
              </button>
              <button 
                onClick={() => handleApproachChange("psychodynamic")}
                className={`px-3 py-1 text-sm rounded-md transition-colors ${
                  approach === "psychodynamic" 
                    ? `${primaryBg} text-white` 
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                Psychodynamic
              </button>
              <button 
                onClick={() => handleApproachChange("mindfulness")}
                className={`px-3 py-1 text-sm rounded-md transition-colors ${
                  approach === "mindfulness" 
                    ? `${primaryBg} text-white` 
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                Mindfulness
              </button>
            </div>
          </div>
        </div>
        
        {/* Focus Points Display */}
        {focusPoints.trim() && (
          <div className="mt-3 p-2 bg-blue-50 border border-blue-100 rounded-md">
            <div className="flex justify-between items-center">
              <div className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-blue-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                </svg>
                <span className="text-sm font-medium text-blue-700">Focus Points:</span>
              </div>
              <button 
                onClick={() => setShowFocusPointsModal(true)}
                className="text-xs text-blue-600 hover:text-blue-800"
              >
                Edit
              </button>
            </div>
            <p className="text-sm text-blue-700 mt-1 pl-6">{focusPoints}</p>
          </div>
        )}
        
        {/* Current Nudge Display */}
        {nudgesEnabled && currentNudge && (
          <div className="mt-3 p-3 bg-yellow-50 border border-yellow-100 rounded-md animate-pulse">
            <div className="flex items-center mb-1">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-yellow-600 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
              </svg>
              <span className="text-sm font-medium text-yellow-800">Clarity Nudge:</span>
            </div>
            <p className="text-sm text-yellow-700 pl-6">{currentNudge}</p>
          </div>
        )}
      </div>

      <div 
        ref={chatContainerRef}
        className="flex-grow bg-white overflow-y-auto p-4"
      >
        {chatHistory.map((chat) => (
          <motion.div
            key={chat.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className={`mb-4 ${
              chat.sender === "therapist" 
                ? "ml-auto max-w-3/4" 
                : chat.sender === "system" 
                  ? "mx-auto text-center" 
                  : "mr-auto max-w-3/4"
            }`}
          >
            {chat.sender === "system" ? (
              <div className="text-xs text-gray-500 bg-gray-100 rounded-full px-3 py-1 inline-block">
                {chat.message}
              </div>
            ) : (
              <div className={`p-3 rounded-lg ${
                chat.sender === "therapist" 
                  ? `${primaryBg} text-white` 
                  : `${secondaryBg} text-white`
              }`}>
                <p className="text-xs mb-1 opacity-70">
                  {chat.sender === "therapist" ? "You" : patient?.name}
                </p>
                <p>{chat.message}</p>
                <p className="text-xs mt-1 opacity-70">
                  {new Date(chat.timestamp).toLocaleTimeString()}
                </p>
              </div>
            )}
          </motion.div>
        ))}
      </div>

      <div className="bg-white rounded-b-lg shadow-md p-4 border-t border-gray-200">
        <form onSubmit={handleSendMessage} className="flex space-x-2">
          <input
            type="text"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Type your response to the patient..."
            className="flex-grow px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <button
            type="submit"
            className={`${primaryBg} text-white px-4 py-2 rounded-lg hover:opacity-90 transition-opacity`}
          >
            Send
          </button>
        </form>
        <p className="text-xs text-gray-500 mt-2">
          Note: This is a simulated conversation using an AI model trained on {patient?.name}'s history and typical responses for their condition.
        </p>
      </div>
      
      {/* Focus Points Modal */}
      {showFocusPointsModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-lg shadow-xl p-6 max-w-md w-full mx-4"
          >
            <h3 className="text-xl font-semibold text-gray-800 mb-4">Set Focus Points</h3>
            <p className="text-sm text-gray-600 mb-4">
              Enter specific topics or techniques you want to focus on during this rehearsal session.
            </p>
            
            <textarea
              value={focusPoints}
              onChange={(e) => setFocusPoints(e.target.value)}
              rows={5}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent mb-4"
              placeholder="e.g., Practice validating feelings, Explore childhood trauma, Work on breathing techniques..."
            ></textarea>
            
            <div className="flex justify-end space-x-3">
              <button 
                onClick={() => setShowFocusPointsModal(false)}
                className="px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={handleSaveFocusPoints}
                className={`px-4 py-2 ${primaryBg} text-white rounded-md hover:opacity-90 transition-opacity`}
              >
                Save
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </motion.div>
  );
}

export default PatientRehearsal;