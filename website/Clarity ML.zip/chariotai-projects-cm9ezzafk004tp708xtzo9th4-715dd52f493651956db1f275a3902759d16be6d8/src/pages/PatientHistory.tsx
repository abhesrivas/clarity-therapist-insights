import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  ArrowLeftIcon,
  ChevronDownIcon,
  ChevronUpIcon,
  PlusIcon,
  DocumentTextIcon,
  ClipboardDocumentCheckIcon,
  BeakerIcon,
  ChatBubbleLeftRightIcon
} from '@heroicons/react/24/outline';
import { useNotification } from '../context/NotificationContext';

// Mock data
const mockPatients = {
  'p1': {
    id: 'p1',
    name: 'Sarah Johnson',
    diagnosis: ['Generalized Anxiety Disorder', 'Insomnia']
  },
  'p2': {
    id: 'p2',
    name: 'Michael Chen',
    diagnosis: ['Major Depressive Disorder', 'Social Anxiety Disorder']
  },
  'p3': {
    id: 'p3',
    name: 'Emily Rodriguez',
    diagnosis: ['PTSD', 'Panic Disorder']
  }
};

const mockHistory = {
  'p1': [
    {
      id: 'h1',
      date: '2023-06-15T10:30:00Z',
      type: 'Session',
      notes: 'Sarah reported increased anxiety this week, particularly around work deadlines. She described feeling overwhelmed and had difficulty sleeping, averaging 4-5 hours per night. We practiced breathing exercises in session and discussed cognitive restructuring techniques for catastrophic thoughts about work performance. Sarah was receptive and engaged well with the exercises.',
      homework: 'Daily thought journaling, 10-minute breathing practice twice daily, progressive muscle relaxation before bed.',
      metrics: {
        anxiety: 65,
        depression: 40
      },
      insights: [
        'Work stressors are primary anxiety trigger',
        'Sleep disruption exacerbating symptoms',
        'Good engagement with cognitive techniques',
        'Physical relaxation strategies needed'
      ]
    },
    {
      id: 'h2',
      date: '2023-06-01T10:30:00Z',
      type: 'Session',
      notes: 'Sarah reported continued anxiety at work, though slightly improved from last week. She has been practicing the thought journaling we discussed and identified several catastrophic thoughts related to her job performance. She noted that challenging these thoughts has been somewhat helpful, but she still experiences physical symptoms of anxiety. Sleep has improved slightly with the progressive muscle relaxation before bed, now averaging 6 hours per night.',
      homework: 'Continue thought journaling and progressive muscle relaxation. Add 10-minute mindfulness practice in the morning.',
      metrics: {
        anxiety: 60,
        depression: 38
      },
      insights: [
        'Cognitive techniques showing modest improvement',
        'Physical symptoms persist despite cognitive improvement',
        'Sleep improving with relaxation techniques',
        'Morning routine may benefit from mindfulness addition'
      ]
    },
    {
      id: 'h3',
      date: '2023-05-15T10:30:00Z',
      type: 'Session',
      notes: 'Sarah discussed a conflict with her mother that occurred over the weekend. She reported feeling criticized about her career choices and relationship status. This triggered significant anxiety and rumination. We explored the connection between these family interactions and her work anxiety, noting similar themes of perceived judgment and fear of failure. Sarah was receptive to examining these patterns and recognized how her relationship with her mother might be influencing her response to workplace feedback.',
      homework: 'Write a reflection on patterns of interaction with mother and how they might parallel workplace dynamics. Continue thought journaling with focus on family interactions.',
      metrics: {
        anxiety: 68,
        depression: 45
      },
      insights: [
        'Family dynamics emerging as significant anxiety trigger',
        'Parallel patterns between family and workplace interactions',
        'Increased insight into anxiety origins',
        'Good engagement with cognitive work'
      ]
    },
    {
      id: 'h4',
      date: '2023-05-01T09:00:00Z',
      type: 'Assessment',
      notes: 'Conducted formal assessment using GAD-7, PHQ-9, and ISI. Sarah scored 16 on GAD-7 (severe anxiety), 8 on PHQ-9 (mild depression), and 18 on ISI (moderate insomnia). She reported that anxiety symptoms have been present for approximately 8 months, coinciding with a promotion at work that increased her responsibilities. Sleep difficulties developed about 4 months ago and have been worsening. No previous psychiatric history or treatment. Family history of anxiety (mother) and depression (maternal grandmother).',
      metrics: {
        anxiety: 80,
        depression: 40,
        insomnia: 75
      },
      assessmentResults: {
        'GAD-7': 16,
        'PHQ-9': 8,
        'ISI': 18
      },
      insights: [
        'Severe anxiety with onset tied to work promotion',
        'Mild depressive symptoms secondary to anxiety',
        'Moderate to severe insomnia developing after anxiety',
        'Family history suggests possible genetic component'
      ]
    }
  ],
  'p2': [
    {
      id: 'h1',
      date: '2023-06-10T14:00:00Z',
      type: 'Session',
      notes: 'Michael reported increased depression this week following a negative performance review at work. He described feeling "worthless" and "a failure," with thoughts that he "will never succeed at anything." Sleep has been disrupted with early morning awakening around 4am and difficulty returning to sleep. He did complete the behavioral activation homework, attending a photography meetup, which he acknowledged provided temporary mood improvement. However, he reported significant anxiety during the social interactions and left early. We worked on identifying and challenging his negative thoughts about the work review, noting the all-or-nothing thinking patterns.',
      homework: 'Continue daily mood tracking. Schedule two photography outings (solo). Practice thought challenging worksheet for work-related negative thoughts.',
      metrics: {
        anxiety: 58,
        depression: 72
      },
      insights: [
        'Work performance strongly tied to self-worth',
        'All-or-nothing thinking pattern prominent',
        'Behavioral activation showing some benefit despite anxiety',
        'Sleep disruption exacerbating mood symptoms'
      ]
    },
    {
      id: 'h2',
      date: '2023-06-03T14:00:00Z',
      type: 'Session',
      notes: 'Michael reported slightly improved mood this week after starting the daily walking routine we discussed. He noted that mornings remain the most difficult time, with low motivation and energy. We explored his reluctance to reach out to former friends, identifying fears of rejection and being judged for his career setbacks. Michael shared a childhood memory of his father criticizing him for getting second place in a math competition, saying "second place is just the first loser." We discussed how this experience might relate to his current perfectionism and fear of judgment. He showed good insight into this connection.',
      homework: 'Continue daily walks. Attend one photography meetup (old hobby). Begin thought record focusing on social anxiety thoughts.',
      metrics: {
        anxiety: 60,
        depression: 65
      },
      insights: [
        'Physical activity showing positive impact on mood',
        'Childhood experiences informing current perfectionism',
        'Social anxiety strongly tied to fear of judgment',
        'Good insight development regarding origins of thought patterns'
      ]
    }
  ],
  'p3': [
    {
      id: 'h1',
      date: '2023-06-12T11:00:00Z',
      type: 'Session',
      notes: 'Emily reported successfully completing the exposure exercise of driving on the highway for 15 minutes. She experienced moderate anxiety (SUDS 6/10) but was able to use breathing techniques to manage symptoms. She had one panic attack this week, triggered by a car backfiring near her workplace. She was able to implement grounding techniques more quickly than previous episodes and the attack lasted approximately 10 minutes (down from typical 25-30 minutes). Sleep remains disrupted with two trauma-related nightmares this week. We continued work on the trauma narrative, focusing on integrating sensory details while maintaining emotional regulation.',
      homework: 'Continue daily grounding practice. Increase highway driving exposure to 20 minutes. Complete trauma narrative section on immediate aftermath of accident.',
      metrics: {
        anxiety: 65,
        depression: 50,
        ptsd: 70
      },
      insights: [
        'Good progress with driving exposure hierarchy',
        'Improved implementation of panic management techniques',
        'Trauma narrative processing proceeding appropriately',
        'Sleep disturbances persisting but stable'
      ]
    }
  ]
};

interface HistoryEntry {
  id: string;
  date: string;
  type: string;
  notes: string;
  homework?: string;
  metrics: Record<string, number>;
  insights: string[];
  assessmentResults?: Record<string, number>;
}

const PatientHistory: React.FC = () => {
  const { patientId } = useParams<{ patientId: string }>();
  const { addNotification } = useNotification();
  const [patient, setPatient] = useState<any>(null);
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [expandedEntries, setExpandedEntries] = useState<Record<string, boolean>>({});
  const [isLoading, setIsLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  
  useEffect(() => {
    // Simulate loading data
    const timer = setTimeout(() => {
      if (patientId) {
        const patientData = mockPatients[patientId as keyof typeof mockPatients];
        const historyData = mockHistory[patientId as keyof typeof mockHistory] || [];
        
        if (patientData) {
          setPatient(patientData);
          setHistory(historyData);
          
          // Initialize first entry as expanded
          if (historyData.length > 0) {
            setExpandedEntries({ [historyData[0].id]: true });
          }
        }
      }
      
      setIsLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, [patientId]);
  
  const toggleExpand = (entryId: string) => {
    setExpandedEntries(prev => ({
      ...prev,
      [entryId]: !prev[entryId]
    }));
  };
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
  };
  
  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
  };
  
  const getEntryTypeIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case 'session':
        return <ChatBubbleLeftRightIcon className="h-5 w-5" />;
      case 'assessment':
        return <ClipboardDocumentCheckIcon className="h-5 w-5" />;
      case 'test':
        return <BeakerIcon className="h-5 w-5" />;
      default:
        return <DocumentTextIcon className="h-5 w-5" />;
    }
  };
  
  const getEntryTypeClass = (type: string) => {
    switch (type.toLowerCase()) {
      case 'session':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      case 'assessment':
        return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200';
      case 'test':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
    }
  };
  
  const filteredHistory = filter === 'all' 
    ? history 
    : history.filter(entry => entry.type.toLowerCase() === filter.toLowerCase());
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        duration: 0.3
      }
    }
  };
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
      </div>
    );
  }
  
  if (!patient) {
    return (
      <div className="flex flex-col items-center justify-center h-full">
        <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-2">Patient Not Found</h2>
        <p className="text-gray-600 dark:text-gray-400 mb-4">The requested patient could not be found.</p>
        <Link
          to="/patients"
          className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800"
        >
          <ArrowLeftIcon className="h-5 w-5 mr-2" />
          Back to Patients
        </Link>
      </div>
    );
  }
  
  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-6"
    >
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center">
          <Link
            to={`/patients/${patientId}`}
            className="mr-4 p-2 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
          >
            <ArrowLeftIcon className="h-5 w-5" />
          </Link>
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{patient.name}</h1>
            <p className="text-sm text-gray-500 dark:text-gray-400">{patient.diagnosis.join(', ')}</p>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-2">
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="block w-full sm:w-auto pl-3 pr-10 py-2 text-base border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md dark:bg-gray-700 dark:text-white"
          >
            <option value="all">All Entries</option>
            <option value="session">Sessions Only</option>
            <option value="assessment">Assessments Only</option>
            <option value="test">Tests Only</option>
          </select>
          
          <button
            onClick={() => addNotification({
              type: 'info',
              title: 'Coming Soon',
              message: 'The add entry feature is coming soon!',
              autoDismiss: true
            })}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800"
          >
            <PlusIcon className="h-5 w-5 mr-2" />
            Add Entry
          </button>
        </div>
      </div>
      
      <div className="bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
          <h2 className="text-lg font-semibold text-gray-800 dark:text-white">Patient History</h2>
        </div>
        
        {filteredHistory.length === 0 ? (
          <div className="p-6 text-center">
            <p className="text-gray-500 dark:text-gray-400">No history entries found.</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-200 dark:divide-gray-700">
            {filteredHistory.map((entry) => (
              <div key={entry.id} className="px-6 py-4">
                <div 
                  className="flex items-center justify-between cursor-pointer"
                  onClick={() => toggleExpand(entry.id)}
                >
                  <div className="flex items-center">
                    <div className={`p-2 rounded-full ${getEntryTypeClass(entry.type)} mr-4`}>
                      {getEntryTypeIcon(entry.type)}
                    </div>
                    <div>
                      <h3 className="text-base font-medium text-gray-900 dark:text-white">{entry.type}</h3>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {formatDate(entry.date)} at {formatTime(entry.date)}
                      </p>
                    </div>
                  </div>
                  <button className="p-1 rounded-full text-gray-500 hover:text-gray-700 hover:bg-gray-100 dark:text-gray-400 dark:hover:text-gray-200 dark:hover:bg-gray-700 transition-colors">
                    {expandedEntries[entry.id] ? (
                      <ChevronUpIcon className="h-5 w-5" />
                    ) : (
                      <ChevronDownIcon className="h-5 w-5" />
                    )}
                  </button>
                </div>
                
                {expandedEntries[entry.id] && (
                  <div className="mt-4 pl-14">
                    <div className="mb-4">
                      <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">Notes</h4>
                      <p className="text-sm text-gray-900 dark:text-white whitespace-pre-line">{entry.notes}</p>
                    </div>
                    
                    {entry.homework && (
                      <div className="mb-4">
                        <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">Homework</h4>
                        <p className="text-sm text-gray-900 dark:text-white">{entry.homework}</p>
                      </div>
                    )}
                    
                    {entry.assessmentResults && (
                      <div className="mb-4">
                        <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">Assessment Results</h4>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                          {Object.entries(entry.assessmentResults).map(([key, value]) => (
                            <div key={key} className="bg-gray-50 dark:bg-gray-700 p-2 rounded">
                              <span className="text-xs text-gray-500 dark:text-gray-400">{key}:</span>
                              <span className="ml-1 text-sm font-medium text-gray-900 dark:text-white">{value}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    <div className="mb-4">
                      <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">Metrics</h4>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                        {Object.entries(entry.metrics).map(([key, value]) => (
                          <div key={key} className="bg-gray-50 dark:bg-gray-700 p-2 rounded">
                            <span className="text-xs text-gray-500 dark:text-gray-400">{key.charAt(0).toUpperCase() + key.slice(1)}:</span>
                            <span className="ml-1 text-sm font-medium text-gray-900 dark:text-white">{value}%</span>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">Key Insights</h4>
                      <ul className="list-disc list-inside text-sm text-gray-900 dark:text-white space-y-1">
                        {entry.insights.map((insight, index) => (
                          <li key={index}>{insight}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </motion.div>
  );
};

export default PatientHistory;