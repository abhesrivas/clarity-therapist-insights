import React from 'react';
import { Link } from 'react-router-dom';

interface LogoProps {
  size?: 'small' | 'medium' | 'large';
  className?: string;
}

const Logo: React.FC<LogoProps> = ({ size = 'medium', className = '' }) => {
  const sizeClasses = {
    small: 'text-xl',
    medium: 'text-2xl',
    large: 'text-3xl'
  };

  return (
    <Link to="/" className={`flex items-center ${className}`}>
      <div className="flex items-center">
        <div className="bg-white dark:bg-gray-700 p-1 rounded-lg">
          <svg 
            className={`${size === 'small' ? 'h-6 w-6' : size === 'medium' ? 'h-8 w-8' : 'h-10 w-10'} text-indigo-600 dark:text-indigo-400`} 
            viewBox="0 0 24 24" 
            fill="none" 
            xmlns="http://www.w3.org/2000/svg"
          >
            <path 
              d="M12 4.75L19.25 9L12 13.25L4.75 9L12 4.75Z" 
              stroke="currentColor" 
              strokeWidth="1.5" 
              strokeLinecap="round" 
              strokeLinejoin="round" 
            />
            <path 
              d="M9.25 11.5L4.75 14.5L12 19.25L19.25 14.5L14.6722 11.5" 
              stroke="currentColor" 
              strokeWidth="1.5" 
              strokeLinecap="round" 
              strokeLinejoin="round" 
            />
            <path 
              d="M12 13.5V19" 
              stroke="currentColor" 
              strokeWidth="1.5" 
              strokeLinecap="round" 
              strokeLinejoin="round" 
            />
          </svg>
        </div>
        {size !== 'small' && (
          <span className={`ml-2 font-bold ${sizeClasses[size]} text-white dark:text-white`}>
            Clarity
          </span>
        )}
      </div>
    </Link>
  );
};

export default Logo;