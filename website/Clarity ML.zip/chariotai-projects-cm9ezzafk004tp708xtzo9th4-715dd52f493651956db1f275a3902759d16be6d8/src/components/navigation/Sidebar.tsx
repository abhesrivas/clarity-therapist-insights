import { NavLink } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  HomeIcon, 
  UsersIcon, 
  ChatBubbleLeftRightIcon, 
  BookOpenIcon, 
  Cog6ToothIcon,
  UserCircleIcon,
  ArrowLeftOnRectangleIcon,
  ChevronLeftIcon,
  ChevronRightIcon
} from '@heroicons/react/24/outline';
import Logo from '../ui/Logo';
import { useAuth } from '../../context/AuthContext';

interface SidebarProps {
  isOpen: boolean;
  toggleSidebar: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, toggleSidebar }) => {
  const { logout, user } = useAuth();

  const sidebarVariants = {
    open: { width: '240px', transition: { duration: 0.3 } },
    closed: { width: '80px', transition: { duration: 0.3 } }
  };

  const navItems = [
    { name: 'Dashboard', path: '/', icon: HomeIcon },
    { name: 'Patients', path: '/patients', icon: UsersIcon },
    { name: 'Chat Analysis', path: '/patients/:patientId/chat', icon: ChatBubbleLeftRightIcon },
    { name: 'Literature', path: '/literature', icon: BookOpenIcon },
    { name: 'Profile', path: '/profile', icon: UserCircleIcon },
    { name: 'Settings', path: '/settings', icon: Cog6ToothIcon },
  ];

  return (
    <motion.div
      variants={sidebarVariants}
      animate={isOpen ? 'open' : 'closed'}
      className="bg-indigo-700 text-white flex flex-col h-full shadow-lg relative dark:bg-gray-800"
    >
      <div className="p-4 flex items-center justify-between">
        <Logo size={isOpen ? 'medium' : 'small'} />
        <button 
          onClick={toggleSidebar}
          className="p-1 rounded-full hover:bg-indigo-600 dark:hover:bg-gray-700 transition-colors"
        >
          {isOpen ? (
            <ChevronLeftIcon className="h-5 w-5" />
          ) : (
            <ChevronRightIcon className="h-5 w-5" />
          )}
        </button>
      </div>

      <div className="flex-1 overflow-y-auto">
        <nav className="mt-8 px-2 space-y-1">
          {navItems.map((item) => (
            <NavLink
              key={item.name}
              to={item.path}
              className={({ isActive }) => 
                `flex items-center px-4 py-3 text-sm font-medium rounded-md transition-colors ${
                  isActive 
                    ? 'bg-indigo-800 text-white dark:bg-gray-700' 
                    : 'text-indigo-100 hover:bg-indigo-600 dark:text-gray-300 dark:hover:bg-gray-700'
                }`
              }
            >
              <item.icon className="h-5 w-5 mr-3" />
              {isOpen && <span>{item.name}</span>}
            </NavLink>
          ))}
        </nav>
      </div>

      <div className="p-4 border-t border-indigo-800 dark:border-gray-700">
        {isOpen && (
          <div className="flex items-center mb-4">
            <div className="h-8 w-8 rounded-full bg-indigo-500 flex items-center justify-center">
              {user?.name?.charAt(0) || 'U'}
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium">{user?.name || 'User'}</p>
              <p className="text-xs text-indigo-200 dark:text-gray-400">{user?.email || 'user@example.com'}</p>
            </div>
          </div>
        )}
        <button
          onClick={logout}
          className="flex items-center w-full px-4 py-2 text-sm font-medium rounded-md text-indigo-100 hover:bg-indigo-600 dark:text-gray-300 dark:hover:bg-gray-700 transition-colors"
        >
          <ArrowLeftOnRectangleIcon className="h-5 w-5 mr-3" />
          {isOpen && <span>Logout</span>}
        </button>
      </div>
    </motion.div>
  );
};

export default Sidebar;