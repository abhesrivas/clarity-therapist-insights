import { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AnimatePresence } from 'framer-motion';

// Layouts
import MainLayout from './layouts/MainLayout';
import AuthLayout from './layouts/AuthLayout';

// Pages
import Dashboard from './pages/Dashboard';
import PatientList from './pages/PatientList';
import PatientDetail from './pages/PatientDetail';
import PatientHistory from './pages/PatientHistory';
import PatientInsights from './pages/PatientInsights';
import TherapistProfile from './pages/TherapistProfile';
import Login from './pages/Login';
import Register from './pages/Register';
import NotFound from './pages/NotFound';
import PatientChat from './pages/PatientChat';
import LiteratureSearch from './pages/LiteratureSearch';
import Settings from './pages/Settings';

// Context
import { AuthProvider } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';
import { NotificationProvider } from './context/NotificationContext';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  return (
    <ThemeProvider>
      <AuthProvider>
        <NotificationProvider>
          <Router>
            <AnimatePresence mode="wait">
              <Routes>
                {/* Auth Routes */}
                <Route path="/login" element={<AuthLayout><Login /></AuthLayout>} />
                <Route path="/register" element={<AuthLayout><Register /></AuthLayout>} />
                
                {/* Protected Routes */}
                <Route path="/" element={<MainLayout />}>
                  <Route index element={<Dashboard />} />
                  <Route path="patients" element={<PatientList />} />
                  <Route path="patients/:patientId" element={<PatientDetail />} />
                  <Route path="patients/:patientId/history" element={<PatientHistory />} />
                  <Route path="patients/:patientId/insights" element={<PatientInsights />} />
                  <Route path="patients/:patientId/chat" element={<PatientChat />} />
                  <Route path="profile" element={<TherapistProfile />} />
                  <Route path="literature" element={<LiteratureSearch />} />
                  <Route path="settings" element={<Settings />} />
                </Route>
                
                {/* 404 Route */}
                <Route path="*" element={<NotFound />} />
              </Routes>
            </AnimatePresence>
          </Router>
        </NotificationProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;