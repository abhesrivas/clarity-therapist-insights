import { useState, useEffect, useRef } from "react";
import { useParams } from "react-router-dom";
import { motion } from "framer-motion";
import { useTheme } from "../utils/themeContext";
import { getPatientById } from "../utils/patientData";

function Chat() {
  const { patientId, id: therapistId } = useParams<{ patientId: string; id: string }>();
  const [patient, setPatient] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");
  const [chatHistory, setChatHistory] = useState<any[]>([]);
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const { getColor } = useTheme();
  
  // Get colors from theme
  const primaryColor = `text-${getColor('primary')}`;
  const primaryBg = `bg-${getColor('primary')}`;

  useEffect(() => {
    // Fetch patient data
    if (patientId) {
      const patientData = getPatientById(patientId);
      if (patientData) {
        setPatient(patientData);
        
        // Initialize chat with context
        setChatHistory([
          { 
            id: 1, 
            sender: "system", 
            message: `Chat started about patient ${patientData.name}`, 
            timestamp: new Date().toISOString() 
          },
          { 
            id: 2, 
            sender: "assistant", 
            message: `I have loaded ${patientData.name}'s history. Their last session was on ${new Date(patientData.lastSession).toLocaleDateString()} where they discussed ${patientData.history[0].notes.substring(0, 100)}... How can I help you analyze this patient's case?`, 
            timestamp: new Date().toISOString() 
          },
        ]);
      }
      setLoading(false);
    }
  }, [patientId]);

  useEffect(() => {
    // Scroll to bottom when chat history updates
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [chatHistory]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    
    // Add message to chat history
    const newMessage = {
      id: chatHistory.length + 1,
      sender: "user",
      message: message,
      timestamp: new Date().toISOString()
    };
    
    setChatHistory([...chatHistory, newMessage]);
    setMessage("");
    
    // Simulate LLM response (in a real app, this would call an API)
    setTimeout(() => {
      let responseMessage;
      
      // Generate different responses based on the message content
      if (message.toLowerCase().includes("diagnosis")) {
        responseMessage = {
          id: chatHistory.length + 2,
          sender: "assistant",
          message: `Based on ${patient.name}'s history, they have been diagnosed with ${patient.diagnosis.join(", ")}. Their symptoms have been ${patient.metrics.anxiety > 60 ? "showing high anxiety levels" : "showing moderate anxiety levels"} and ${patient.metrics.depression > 60 ? "significant depressive symptoms" : "mild depressive symptoms"}. The treatment approach so far has focused on ${patient.history[0].notes.substring(0, 100)}...`,
          timestamp: new Date().toISOString()
        };
      } else if (message.toLowerCase().includes("progress") || message.toLowerCase().includes("improvement")) {
        responseMessage = {
          id: chatHistory.length + 2,
          sender: "assistant",
          message: `${patient.name} has shown ${patient.metrics.wellbeing > 60 ? "good progress" : "some progress"} over the last few sessions. Their anxiety metrics have ${patient.metrics.anxiety > patient.metrics.depression ? "been the primary concern" : "improved more than their depression metrics"}. Based on session notes, they've been particularly responsive to ${patient.history[0].notes.includes("mindfulness") ? "mindfulness techniques" : "cognitive restructuring exercises"}.`,
          timestamp: new Date().toISOString()
        };
      } else {
        responseMessage = {
          id: chatHistory.length + 2,
          sender: "assistant",
          message: `I've analyzed ${patient.name}'s case history. They've been in treatment for ${patient.history.length} documented sessions, focusing primarily on their ${patient.diagnosis[0]}. Recent sessions indicate ${patient.history[0].notes.includes("improvement") ? "some improvement" : "ongoing challenges"}. Would you like me to analyze any specific aspect of their treatment or symptoms?`,
          timestamp: new Date().toISOString()
        };
      }
      
      setChatHistory(prev => [...prev, responseMessage]);
    }, 1000);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className={`animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-${getColor('primary')}`}></div>
      </div>
    );
  }

  if (!patient) {
    return (
      <div className="space-y-6">
        <h1 className={`text-3xl font-bold ${primaryColor} mb-6`}>Chat about Patient</h1>
        <div className="bg-white p-6 rounded-lg shadow-md text-center">
          <p className="text-gray-600">Patient not found. Please select a patient from the dashboard.</p>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="h-[calc(100vh-200px)] flex flex-col"
    >
      <div className="bg-white rounded-t-lg shadow-md p-4 border-b border-gray-200">
        <h2 className="text-xl font-semibold text-gray-800">
          Chat about {patient.name}
        </h2>
        <p className="text-sm text-gray-500">
          Ask questions about patient history, treatment options, or analysis
        </p>
      </div>

      <div 
        ref={chatContainerRef}
        className="flex-grow bg-white overflow-y-auto p-4"
      >
        {chatHistory.map((chat) => (
          <motion.div
            key={chat.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className={`mb-4 ${
              chat.sender === "user" 
                ? "ml-auto max-w-3/4" 
                : chat.sender === "system" 
                  ? "mx-auto text-center" 
                  : "mr-auto max-w-3/4"
            }`}
          >
            {chat.sender === "system" ? (
              <div className="text-xs text-gray-500 bg-gray-100 rounded-full px-3 py-1 inline-block">
                {chat.message}
              </div>
            ) : (
              <div className={`p-3 rounded-lg ${
                chat.sender === "user" 
                  ? `${primaryBg} text-white` 
                  : "bg-gray-100 text-gray-800"
              }`}>
                <p>{chat.message}</p>
                <p className="text-xs mt-1 opacity-70">
                  {new Date(chat.timestamp).toLocaleTimeString()}
                </p>
              </div>
            )}
          </motion.div>
        ))}
      </div>

      <div className="bg-white rounded-b-lg shadow-md p-4 border-t border-gray-200">
        <form onSubmit={handleSendMessage} className="flex space-x-2">
          <input
            type="text"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Ask about this patient's history, treatment options, or analysis..."
            className="flex-grow px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <button
            type="submit"
            className={`${primaryBg} text-white px-4 py-2 rounded-lg hover:opacity-90 transition-opacity`}
          >
            Send
          </button>
        </form>
      </div>
    </motion.div>
  );
}

export default Chat;